//vbdb2

export const PRODUCTION_VBDB2_API_URL = 'http://test.com/api/v2';

export const TEST_VBDB2_API_URL = 'http://test.com/api/v2';
export const TEST_VBDB2_API_DOCS_URL = 'http://test.com/api/v2';
export const PRODUCTION_VBDB2_URL = 'http://test.com/api/v2';
export const TEST_VBDB2_URL = 'http://test.com/api/v2';
// redmine

export const PRODUCTION_REDMINE_API_URL = 'http://test.com/api/v2';

export const TEST_REDMINE_API_URL = 'http://test.com/api/v2';

export const REDMINE_API_KEY = '3b352811736ad29309aabcfb2705a339657e6c61';

// others

export const TEST_USER_ID = 'J0134484';

export const ENG_UI_URL = 'http://test.com/api/v2';
