import axios, { AxiosInstance } from 'axios';
import { useCookies } from 'react-cookie';
import {
  PRODUCTION_REDMINE_API_URL,
  TEST_REDMINE_API_URL,
  REDMINE_API_KEY
} from 'src/utils/url';

export const useAxiosRedmineInstance = () => {
  const [cookies] = useCookies();

  const axiosRedmineInstance: AxiosInstance = axios.create({
    baseURL:
      cookies['ENV'] === undefined
        ? TEST_REDMINE_API_URL
        : PRODUCTION_REDMINE_API_URL,
    params: {
      key: REDMINE_API_KEY
    },
    timeout: 300000
  });

  return axiosRedmineInstance;
};
