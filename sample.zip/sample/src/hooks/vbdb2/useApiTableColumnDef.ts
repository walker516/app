import { useCallback } from 'react';
import { ColDef, ColGroupDef } from 'ag-grid-community';

import { useTargetTable } from 'src/contexts/DataGridProvider';
import { useAxiosVbdb2Instance } from './useAxiosVbdb2Instance';

import apiTableColumnDefs from 'src/db/apiTableColumnDef.json';
import apiTableColumns from 'src/db/apiTableColumn.json';
import {
  TableColumn,
  TableColumnGroup,
  Column
} from 'src/types/api/tableColumn';

type Obj = Record<string, any>;
const mapColumns = (arr: Column[]): (ColDef | ColGroupDef)[] => {
  const result: (ColDef | ColGroupDef)[] = [];
  const superGroups: { [key: string]: ColGroupDef } = {};

  for (let i = 0; i < arr.length; i++) {
    const { column_id, name1, name2, name3, type } = arr[i];

    if (!superGroups[name1]) {
      const groupId = `g${result.length + 1}`;
      superGroups[name1] = {
        groupId,
        headerName: name1,
        children: []
      };
      result.push(superGroups[name1]);
    }

    const superGroup = superGroups[name1];
    let subGroup = superGroup.children.find((sub) => sub.headerName === name2);

    if (!subGroup) {
      const groupId = `g${superGroup.groupId}-${
        superGroup.children.length + 1
      }`;
      subGroup = {
        groupId,
        headerName: name2,
        children: []
      };
      superGroup.children.push(subGroup);
    }

    const valueFormatter = (params: any) => {
      const regexp = /^NUM(\d)$/;

      if (regexp.test(type)) {
        const value = parseFloat(params.value);

        if (isNaN(value)) {
          return params.value;
        } else {
          const extractNumber = (type: string) => {
            const match = type.match(regexp);
            return parseInt(match[1]);
          };

          const formatOptions = {
            minimumFractionDigits: extractNumber(type),
            maximumFractionDigits: extractNumber(type)
          };

          return new Intl.NumberFormat('en-US', formatOptions).format(value);
        }
      } else {
        return params.value;
      }
    };
    (subGroup as ColGroupDef).children.push({
      field: column_id,
      headerName: name3,
      valueFormatter
    });
  }

  return result;
};
export const useApiTableColumnDef = () => {
  const { setColumnDef, setPinnedUnitData } = useTargetTable();
  const axiosVbdb2Instance = useAxiosVbdb2Instance();

  const mapColumnDefs = (
    props: TableColumn | TableColumnGroup
  ): ColDef | ColGroupDef => {
    if ('children' in props) {
      return {
        headerName: props.name,
        groupId: props.group_id,
        children: props.children.map(mapColumnDefs).filter(Boolean)
      };
    } else {
      const valueFormatter = (params) => {
        const regexp = /^NUM(\d)$/;

        if (regexp.test(props.type)) {
          const value = parseFloat(params.value);

          if (isNaN(value)) {
            return params.value;
          } else {
            const extractNumber = (type: string) => {
              const match = type.match(regexp);
              return parseInt(match[1]);
            };

            const formatOptions = {
              minimumFractionDigits: extractNumber(props.type),
              maximumFractionDigits: extractNumber(props.type)
            };

            return new Intl.NumberFormat('en-US', formatOptions).format(value);
          }
        } else {
          return params.value;
        }
      };
      return {
        headerName: props.name,
        field: props.column_id,
        hide: props.hidden,
        valueFormatter
      };
    }
  };

  const pinnedUnitData: Obj = {};
  const mapPinnedUnit = (props: TableColumn | TableColumnGroup) => {
    if ('children' in props) {
      props.children.forEach(mapPinnedUnit);
    } else {
      pinnedUnitData[props.column_id] = props.unit;
    }
  };

  const getAgColumnDef = useCallback((tableId: string) => {
    console.log('List Column-Definitions: ', tableId);
    if (!tableId || tableId == '') return;

    // axiosVbdb2Instance
    //   .get<(TableColumn | TableColumnGroup)[]>(`/tables/${tableId}/columnDefs`)
    //   .then(async (res) => {
    //     const agColumnDef: (ColDef | ColGroupDef)[] = res.data
    //       .map(mapColumnDefs)
    //       .filter(Boolean);
    //     if (!('children' in agColumnDef[0])) {
    //       agColumnDef[0].pinned = 'left';
    //       agColumnDef[0].lockPinned = true;
    //       agColumnDef[0].cellClass = 'lock-pinned';
    //     }
    //     setColumnDef(agColumnDef);

    //     res.data.forEach(mapPinnedUnit);
    //     setPinnedUnitData(pinnedUnitData);
    //   })
    //   .catch((error) => {
    //     console.log(error);
    //   });

    // const tmp: (TableColumn | TableColumnGroup)[] = apiTableColumnDefs;
    // const agColumnDef: (ColDef | ColGroupDef)[] = tmp
    //   .map(mapColumnDefs)
    //   .filter(Boolean);
    // if (!('children' in agColumnDef[0])) {
    //   agColumnDef[0].pinned = 'left';
    //   agColumnDef[0].lockPinned = true;
    //   agColumnDef[0].cellClass = 'lock-pinned';
    // }
    const tmp: Column[] = apiTableColumns;
    const tmpColumnDef: (ColDef | ColGroupDef)[] = apiTableColumnDefs
      .map(mapColumnDefs)
      .filter(Boolean);
    const agColumnDef: (ColDef | ColGroupDef)[] = mapColumns(tmp);
    if (!('children' in agColumnDef[0])) {
      agColumnDef[0].pinned = 'left';
      agColumnDef[0].lockPinned = true;
      agColumnDef[0].cellClass = 'lock-pinned';
    }
    console.log('after: ', mapColumns(tmp));
    console.log('before: ', tmpColumnDef);
    setColumnDef(agColumnDef);
    tmp.forEach((column) => (pinnedUnitData[column.column_id] = column.unit));
    // tmp.forEach(mapPinnedUnit);
    setPinnedUnitData(pinnedUnitData);
  }, []);
  return {
    getAgColumnDef
  };
};
