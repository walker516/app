export type Feedback = {
  id?: number;
  userId: string;
  tracker: string; //[不具合]: 1, [要望]: 2, [その他]: 3
  status: string; //[新規]: 1, [進行中]: 2, [終了]: 5
  subject: string;
  description?: string;
  startDate: string;
  fileName?: string;
};

export type PostFeedback = {
  userId: string;
  tracker: string; //[不具合]: 1, [要望]: 2, [その他]: 3
  subject: string;
  description?: string;
  postFileData?: File;
};
