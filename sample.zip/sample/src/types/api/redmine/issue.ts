export type Issue = {
  id: number;
  tracker: { id: number; name: string }; //[不具合]: 1, [要望]: 2, [その他]: 3
  status: { id: number; name: string }; //[新規]: 1, [進行中]: 2, [テスト中]: 9, [終了]: 5
  subject: string;
  description: string;
  start_date: string;
  custom_fields: { id: number; value: string }[];
  project_id: string;
  attachments: { filename: string }[];
};

export type ListIssues = {
  issues: Issue[];
};

export type PostIssue = {
  issue: Omit<Issue, 'id' | 'status' | 'attachments'> & {
    tracker_id?: number;
    custom_fields?: { id: number; name: string }; //[user_id]: 34
    uploads?: { token?: string; filename?: string };
  };
};
