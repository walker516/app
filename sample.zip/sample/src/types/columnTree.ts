export type ColumnTree = {
  id: string;
  name: string;
  hide?: boolean;
  children?: ColumnTree[];
};
