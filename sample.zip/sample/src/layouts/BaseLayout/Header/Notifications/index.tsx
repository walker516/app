import {
  alpha,
  Badge,
  Box,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Divider,
  IconButton,
  Popover,
  Tooltip,
  Typography,
  styled,
  Button
} from '@mui/material';
import { useRef, useState } from 'react';
import NotificationsActiveTwoToneIcon from '@mui/icons-material/NotificationsActiveTwoTone';
import NewReleasesIcon from '@mui/icons-material/NewReleases';

import notifincations from './notifications.json';

const NotificationsBadge = styled(Badge)(
  ({ theme }) => `
    
    .MuiBadge-badge {
        background-color: ${theme.palette.error.main};
        color: ${theme.palette.error.contrastText};
        min-width: 18px; 
        height: 18px;
        padding: 0;

        &::after {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            box-shadow: 0 0 0 1px ${alpha(theme.palette.error.main, 0.3)};
            content: "";
        }
    }
`
);

const IconButtonPrimary = styled(IconButton)(
  ({ theme }) => `
    margin-left: ${theme.spacing(1)};
    background: ${theme.colors.alpha.trueWhite[10]};
    color: ${theme.colors.alpha.trueWhite[70]};
    padding: 0;
    width: 42px;
    height: 42px;
    border-radius: 100%;
    transition: ${theme.transitions.create(['background', 'color'])};

    &.active,
    &:active,
    &:hover {
      background: ${alpha(theme.colors.alpha.trueWhite[30], 0.2)};
      color: ${theme.colors.alpha.trueWhite[100]};
    }
`
);

function HeaderNotifications() {
  const ref = useRef<any>(null);
  const [isOpen, setOpen] = useState<boolean>(false);
  const extractNotifincations = notifincations.filter((notification) => {
    const date = new Date(notification.date);
    const today = new Date();
    return date.getTime() < today.getTime();
  });
  const [displayedNotifications, setDisplayedNotifications] = useState<
    typeof notifincations
  >(
    extractNotifincations
      .filter((notification) => {
        const date = new Date(notification.date);
        const today = new Date();
        return date.getTime() < today.getTime();
      })
      .slice(0, 3)
  );
  const badgeCountNotifications = extractNotifincations
    .filter((notification) => {
      const date = new Date(notification.date);
      const today = new Date();
      const timeDiff = Math.abs(today.getTime() - date.getTime());
      const diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
      return diffDays <= 7;
    })
    .reverse();
  const badgeContent = badgeCountNotifications.length;

  const handleOpen = (): void => {
    setOpen(true);
  };

  const handleClose = (): void => {
    setOpen(false);
  };

  const handleViewAll = (): void => {
    setDisplayedNotifications(extractNotifincations);
  };

  const viewAllButton =
    extractNotifincations.length > displayedNotifications.length ? (
      <Button color="secondary" onClick={handleViewAll} fullWidth>
        View all notifications
      </Button>
    ) : null;
  return (
    <>
      <Tooltip arrow title={'Notifications'}>
        <IconButtonPrimary color="primary" ref={ref} onClick={handleOpen}>
          <NotificationsBadge
            badgeContent={badgeContent}
            anchorOrigin={{
              vertical: 'top',
              horizontal: 'right'
            }}
          >
            <NotificationsActiveTwoToneIcon />
          </NotificationsBadge>
        </IconButtonPrimary>
      </Tooltip>
      <Popover
        disableScrollLock
        anchorEl={ref.current}
        onClose={handleClose}
        open={isOpen}
        anchorOrigin={{
          vertical: 'top',
          horizontal: 'right'
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right'
        }}
      >
        <Box
          sx={{
            p: 2
          }}
          display="flex"
          justifyContent="space-between"
        >
          <Typography variant="h5">Notifications</Typography>
        </Box>
        <Divider />
        <List>
          {displayedNotifications.map((notification, index) => (
            <ListItem key={index}>
              <ListItemIcon>
                <NewReleasesIcon />
              </ListItemIcon>
              <ListItemText
                primary={notification.title}
                secondary={notification.date}
              />
            </ListItem>
          ))}
        </List>
        <Divider />
        {viewAllButton}
      </Popover>
    </>
  );
}

export default HeaderNotifications;
