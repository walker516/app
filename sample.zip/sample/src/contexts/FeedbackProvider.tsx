import {
  createContext,
  Dispatch,
  ReactNode,
  SetStateAction,
  useContext,
  useState
} from 'react';

import { Feedback } from 'src/types/feedback';

type FeedbackContextType = {
  feedbackList: Feedback[] | null;
  setFeedbackList: Dispatch<SetStateAction<Feedback[] | null>>;
};

type Props = {
  children: ReactNode;
};

// eslint-disable-next-line @typescript-eslint/no-redeclare
const FeedbackContext = createContext<FeedbackContextType>(
  {} as FeedbackContextType
);

export const FeedbackProvider = (props: Props) => {
  const { children } = props;
  const [feedbackList, setFeedbackList] = useState<Feedback[] | null>([]);

  return (
    <FeedbackContext.Provider value={{ feedbackList, setFeedbackList }}>
      {children}
    </FeedbackContext.Provider>
  );
};

export const useFeedback = (): FeedbackContextType =>
  useContext(FeedbackContext);
