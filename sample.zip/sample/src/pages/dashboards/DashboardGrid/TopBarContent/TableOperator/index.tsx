import { FC, MutableRefObject, useRef, useState } from 'react';
import {
  Box,
  Drawer,
  IconButton,
  Popover,
  Tooltip,
  useTheme
} from '@mui/material';
import FileDownloadTwoToneIcon from '@mui/icons-material/FileDownloadTwoTone';
import ViewColumnIcon from '@mui/icons-material/ViewColumn';
import FilterListOffIcon from '@mui/icons-material/FilterListOff';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import { AgGridReact } from 'ag-grid-react';
import { useTargetTable } from 'src/contexts/DataGridProvider';
import { useGroup } from 'src/contexts/GroupProvider';
import ColumnList from '../ColumnList';

type Props = {
  gridRef: MutableRefObject<AgGridReact<any>>;
};

const getColor = (groupId: string) => {
  switch (groupId) {
    case 'E':
      return 'info';
    case 'A':
      return 'success';
    case 'C':
      return 'secondary';
    default:
      return 'primary';
  }
};

const TableOperator: FC<Props> = ({ gridRef }) => {
  const { targetTable } = useTargetTable();
  const theme = useTheme();
  const { groupId } = useGroup();
  const [mobileOpen, setMobileOpen] = useState(false);

  const ref = useRef<any>(null);
  const [isOpen, setOpen] = useState<boolean>(false);

  const handleOpen = (): void => {
    setOpen(true);
  };

  const handleClose = (): void => {
    setOpen(false);
  };

  const handleDrawerToggle = () => setMobileOpen(!mobileOpen);
  const getParams = () => ({ fileName: targetTable.name, onlySelected: true });
  const handleExportClick = () =>
    gridRef.current?.api.exportDataAsCsv(getParams());
  const handleFilterResetClick = () =>
    gridRef.current?.api.setFilterModel(null);

  const actions = [
    {
      icon: <ViewColumnIcon />,
      name: 'Column Show/Hide',
      onclick: handleDrawerToggle
    },
    {
      icon: <FileDownloadTwoToneIcon />,
      name: 'CSV Export',
      onclick: handleExportClick
    },
    {
      icon: <FilterListOffIcon />,
      name: ' Filter State Reset',
      onclick: handleFilterResetClick
    }
  ];

  return (
    <>
      <Box
        component="span"
        sx={{
          display: { xs: 'none', md: 'inline-block' }
        }}
      >
        {actions.map(({ icon, name, onclick }) => (
          <Tooltip placement="top-end" title={name} key={name}>
            <IconButton color={getColor(groupId)} onClick={onclick}>
              {icon}
            </IconButton>
          </Tooltip>
        ))}
      </Box>
      <Box
        component="span"
        sx={{
          display: { md: 'none', xs: 'inline-block' }
        }}
      >
        <Tooltip placement="top-end" title="more">
          <IconButton color={getColor(groupId)} ref={ref} onClick={handleOpen}>
            <ChevronRightIcon />
          </IconButton>
        </Tooltip>
        <Popover
          disableScrollLock
          anchorEl={ref.current}
          onClose={handleClose}
          open={isOpen}
          anchorOrigin={{
            vertical: 'top',
            horizontal: 'right'
          }}
          transformOrigin={{
            vertical: 'top',
            horizontal: 'right'
          }}
        >
          <Box component="span">
            {actions.map(({ icon, name, onclick }) => (
              <Tooltip placement="top-end" title={name} key={name}>
                <IconButton color={getColor(groupId)} onClick={onclick}>
                  {icon}
                </IconButton>
              </Tooltip>
            ))}
          </Box>
        </Popover>
      </Box>
      <Drawer
        variant="temporary"
        anchor={theme.direction === 'rtl' ? 'left' : 'right'}
        open={mobileOpen}
        onClose={handleDrawerToggle}
        elevation={9}
      >
        <ColumnList />
      </Drawer>
    </>
  );
};

export default TableOperator;
