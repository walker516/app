import { Dispatch, FC, SetStateAction } from 'react';
import { Box, InputAdornment, TextField } from '@mui/material';
import SearchTwoToneIcon from '@mui/icons-material/SearchTwoTone';

type Props = {
  searchQuery: string;
  setSearchQuery: Dispatch<SetStateAction<string>>;
};

const ColumnSearchBar: FC<Props> = (props) => {
  const { searchQuery, setSearchQuery } = props;
  return (
    <Box flexGrow={1} display="flex" alignItems="center">
      <TextField
        size="small"
        fullWidth
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <SearchTwoToneIcon />
            </InputAdornment>
          )
        }}
        placeholder={'Table Search...'}
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
      />
    </Box>
  );
};

export default ColumnSearchBar;
