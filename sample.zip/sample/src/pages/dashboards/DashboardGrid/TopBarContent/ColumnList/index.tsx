import { FC, useState } from 'react';
import { Box, Divider } from '@mui/material';
import ColumnCheckBoxTree from './ColumnCheckBoxTree';
import ColumnSearchBar from './ColumnSearchBar';

const ColumnList: FC = () => {
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <Box
      sx={{
        minWidth: 360
      }}
      p={2}
    >
      <ColumnSearchBar
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
      />
      <Divider
        sx={{
          my: 1
        }}
      />
      <ColumnCheckBoxTree searchQuery={searchQuery} />
    </Box>
  );
};

export default ColumnList;
