import { FC, useState } from 'react';
import {
  Box,
  Button,
  Divider,
  Drawer,
  Tooltip,
  IconButton,
  useTheme,
  Hidden,
  styled
} from '@mui/material';
import AccountTreeIcon from '@mui/icons-material/AccountTree';

import TableTree from './TableTree';
import { useGroup } from 'src/contexts/GroupProvider';
import SearchBar from './SearchBar';

const getColor = (groupId: string) => {
  switch (groupId) {
    case 'E':
      return 'info';
    case 'A':
      return 'success';
    case 'C':
      return 'secondary';
    default:
      return 'primary';
  }
};

const IconButtonToggle = styled(IconButton)(
  ({ theme }) => `
  width: ${theme.spacing(8)};
  background: ${theme.colors.alpha.white[100]};
`
);

const TableListButton: FC = () => {
  const { groupId, groupMobileOpen, setGroupMobileOpen } = useGroup();
  const theme = useTheme();
  const [searchQuery, setSearchQuery] = useState('');

  const handleDrawerToggle = () => {
    setGroupMobileOpen(!groupMobileOpen);
  };

  return (
    <>
      <Box component="span">
        <Tooltip placement="right-end" title="Table List">
          <IconButtonToggle
            color={getColor(groupId)}
            onClick={handleDrawerToggle}
          >
            <AccountTreeIcon fontSize="large" />
          </IconButtonToggle>
        </Tooltip>
      </Box>
      <Drawer
        sx={{
          boxShadow: `${theme.sidebar.boxShadow}`
        }}
        variant="temporary"
        anchor={theme.direction === 'rtl' ? 'right' : 'left'}
        open={groupMobileOpen}
        onClose={handleDrawerToggle}
        elevation={9}
      >
        <Box
          sx={{
            minWidth: 360
          }}
          p={2}
        >
          <SearchBar
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
          />
          <Divider
            sx={{
              my: 3
            }}
          />
          <TableTree searchQuery={searchQuery} />
        </Box>
      </Drawer>
    </>
  );
};

export default TableListButton;
