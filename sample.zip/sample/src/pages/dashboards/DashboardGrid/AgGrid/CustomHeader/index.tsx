import { FC, useEffect, useRef, useState } from 'react';
import { IHeaderParams } from 'ag-grid-community';
import MenuIcon from '@mui/icons-material/Menu';
import InfoIcon from '@mui/icons-material/Info';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';
import CloseIcon from '@mui/icons-material/Close';

export interface ICustomHeaderParams extends IHeaderParams {
  menuIcon: string;
}

const CustomHeader: FC<ICustomHeaderParams> = (props) => {
  const [ascSort, setAscSort] = useState('inactive');
  const [descSort, setDescSort] = useState('inactive');
  const [noSort, setNoSort] = useState('inactive');
  const refButton = useRef(null);

  const onMenuClicked = () => {
    props.showColumnMenu(refButton.current!);
  };

  const onSortChanged = () => {
    setAscSort(props.column.isSortAscending() ? 'active' : 'inactive');
    setDescSort(props.column.isSortDescending() ? 'active' : 'inactive');
    setNoSort(
      !props.column.isSortAscending() && !props.column.isSortDescending()
        ? 'active'
        : 'inactive'
    );
  };

  const onSortRequested = (order: 'asc' | 'desc' | null, event: any) => {
    props.setSort(order, event.shiftKey);
  };

  useEffect(() => {
    props.column.addEventListener('sortChanged', onSortChanged);
    onSortChanged();
  }, []);

  let menu = null;
  if (props.enableMenu) {
    menu = (
      <div
        ref={refButton}
        className="customHeaderMenuButton"
        onClick={() => onMenuClicked()}
      >
        <MenuIcon sx={{ fontSize: 20 }} />
      </div>
    );
  }

  let sort = null;
  if (props.enableSorting) {
    sort = (
      <div style={{ display: 'flex' }}>
        {/* <a
          onClick={() =>
            alert(
              `Under consideration ... \nThis column's name is "${props.displayName}".`
            )
          }
          className="customHelpIcon"
        >
          <InfoIcon sx={{ fontSize: 15 }} />
        </a> */}
        <div
          onClick={(event) => onSortRequested('asc', event)}
          onTouchEnd={(event) => onSortRequested('asc', event)}
          className={`customSortDownLabel ${ascSort}`}
        >
          {props.column.isSortAscending() ? (
            <ArrowDownwardIcon sx={{ fontSize: 15 }} color={'success'} />
          ) : (
            <ArrowDownwardIcon sx={{ fontSize: 15 }} />
          )}
        </div>
        <div
          onClick={(event) => onSortRequested('desc', event)}
          onTouchEnd={(event) => onSortRequested('desc', event)}
          className={`customSortUpLabel ${descSort}`}
        >
          {props.column.isSortDescending() ? (
            <ArrowUpwardIcon sx={{ fontSize: 15 }} color={'success'} />
          ) : (
            <ArrowUpwardIcon sx={{ fontSize: 15 }} />
          )}
        </div>
        <div
          onClick={(event) => onSortRequested(null, event)}
          onTouchEnd={(event) => onSortRequested(null, event)}
          className={`customSortRemoveLabel ${noSort}`}
        >
          <CloseIcon sx={{ fontSize: 15 }} />
        </div>
      </div>
    );
  }

  return (
    <div style={{ display: 'flex' }}>
      {menu}
      {sort}
      <div className="customHeaderLabel">{props.displayName}</div>
    </div>
  );
};

export default CustomHeader;
