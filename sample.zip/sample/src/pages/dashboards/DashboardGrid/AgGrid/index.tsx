import { memo, MutableRefObject, useEffect, useMemo } from 'react';
import {
  CheckboxSelectionCallbackParams,
  ColDef,
  HeaderCheckboxSelectionCallbackParams
} from 'ag-grid-community';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { AgGridReact } from 'ag-grid-react';
import { Box, CircularProgress, styled } from '@mui/material';

import { useApiTableRowData } from 'src/hooks/vbdb2/useApiTableRowData';
import { useApiTableColumnDef } from 'src/hooks/vbdb2/useApiTableColumnDef';
import { useTargetTable } from 'src/contexts/DataGridProvider';
import CustomHeader from './CustomHeader';

import './styles.css';

type Props = {
  gridRef: MutableRefObject<AgGridReact<any>>;
};

function isFirstColumn(
  params:
    | CheckboxSelectionCallbackParams
    | HeaderCheckboxSelectionCallbackParams
) {
  var displayedColumns = params.columnApi.getAllDisplayedColumns();
  var thisIsFirstColumn = displayedColumns[0] === params.column;
  return thisIsFirstColumn;
}

const AgGrid = memo((props: Props) => {
  const {
    columnDef: agColumnDef,
    targetTable,
    pinnedUnitData
  } = useTargetTable();
  const { getAgColumnDef } = useApiTableColumnDef();
  const { agRowData, getAgRowData, loading } = useApiTableRowData();

  const defaultColDef = useMemo<ColDef>(() => {
    return {
      openByDefault: true,
      sortable: true,
      resizable: true,
      filter: true,
      headerCheckboxSelection: isFirstColumn,
      checkboxSelection: isFirstColumn
    };
  }, []);

  useEffect(() => {
    getAgColumnDef(targetTable.id);
    getAgRowData(targetTable.id);
  }, [targetTable.id]);

  const ProgressBox = styled(Box)(
    () => `
        height: 100%;
        display: flex;
        flex: 1;
        overflow: auto;
        flex-direction: column;
        align-items: center;
        justify-content: center;
    `
  );

  const components = useMemo<{
    [p: string]: any;
  }>(() => {
    return {
      agColumnHeader: CustomHeader
    };
  }, []);
  return (
    <>
      {loading ? (
        <ProgressBox>
          <CircularProgress />
        </ProgressBox>
      ) : (
        <Box className="ag-theme-alpine" sx={{ mx: 2, height: '100%' }}>
          <AgGridReact
            ref={props.gridRef}
            rowData={agRowData}
            columnDefs={agColumnDef}
            defaultColDef={defaultColDef}
            rowSelection={'multiple'}
            pinnedTopRowData={[pinnedUnitData]}
            components={components}
          />
        </Box>
      )}
    </>
  );
});

export default AgGrid;
