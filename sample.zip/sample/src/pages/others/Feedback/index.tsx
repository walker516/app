import { FC, useState } from 'react';
import { Box, Container, Drawer, styled, useTheme } from '@mui/material';

import Footer from 'src/components/Footer';
import { FeedbackProvider } from 'src/contexts/FeedbackProvider';
import FeedbackList from './FeedbackList';
import PageTitle from './PageTitle';
import NewFeedback from './NewFeedback';

const PageTitleWrapper = styled(Box)(
  ({ theme }) => `
        padding: ${theme.spacing(4)};
`
);

const Feedback: FC = () => {
  const theme = useTheme();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };
  return (
    <FeedbackProvider>
      <PageTitleWrapper>
        <Container maxWidth="lg">
          <PageTitle
            heading="ユーザの声"
            subHeading="新UIのフィードバックをお願いします"
            handleDrawerToggle={handleDrawerToggle}
          />
        </Container>
      </PageTitleWrapper>
      <Drawer
        sx={{
          boxShadow: `${theme.sidebar.boxShadow}`
        }}
        variant="temporary"
        anchor={theme.direction === 'rtl' ? 'bottom' : 'top'}
        open={mobileOpen}
        onClose={handleDrawerToggle}
        elevation={9}
      >
        <Box
          sx={{
            minWidth: 360
          }}
          p={2}
        >
          <NewFeedback onClose={handleDrawerToggle} />
        </Box>
      </Drawer>
      <Container maxWidth="lg">
        <FeedbackList />
      </Container>
      <Footer />
    </FeedbackProvider>
  );
};

export default Feedback;
