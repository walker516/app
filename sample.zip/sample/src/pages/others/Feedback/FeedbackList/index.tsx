import { FC, useCallback, useEffect, useState } from 'react';
import {
  Box,
  Card,
  CardHeader,
  ListItemText,
  List,
  ListItem,
  Divider,
  ListItemAvatar,
  Avatar,
  styled,
  Grid,
  CircularProgress,
  ListItemButton
} from '@mui/material';
import LightbulbIcon from '@mui/icons-material/Lightbulb';
import AutorenewIcon from '@mui/icons-material/Autorenew';
import PublishedWithChangesIcon from '@mui/icons-material/PublishedWithChanges';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';

import Text from 'src/components/Text';
import { useFeedback } from 'src/contexts/FeedbackProvider';
import { useApiListIssues } from 'src/hooks/redmine/useApiListIssues';
import { useSelectFeedback } from 'src/hooks/useSelectFeedback';
import FeedbackDetailModal from './FeedbackDetailModal';

const AvatarWrapper = styled(Avatar)(
  ({ theme, color }) => `
  background-color: ${theme.colors[color].lighter};
  color: ${theme.colors[color].main};
`
);

const itemsByState: {
  title: string;
  status: string;
  avatar: JSX.Element;
  color:
    | 'error'
    | 'success'
    | 'warning'
    | 'black'
    | 'primary'
    | 'secondary'
    | 'info';
}[] = [
  {
    title: '新規',
    status: '1',
    avatar: (
      <AvatarWrapper color="error">
        <LightbulbIcon />
      </AvatarWrapper>
    ),
    color: 'error'
  },
  {
    title: '進行中',
    status: '2',
    avatar: (
      <AvatarWrapper color="success">
        <AutorenewIcon />
      </AvatarWrapper>
    ),
    color: 'success'
  },
  {
    title: 'テスト中',
    status: '9',
    avatar: (
      <AvatarWrapper color="warning">
        <PublishedWithChangesIcon />
      </AvatarWrapper>
    ),
    color: 'warning'
  },
  {
    title: '終了',
    status: '5',
    avatar: (
      <AvatarWrapper color="secondary">
        <CheckCircleIcon />
      </AvatarWrapper>
    ),
    color: 'secondary'
  }
];

const FeedbackList: FC = () => {
  const { getFeedbackList, loading } = useApiListIssues();
  const [open, setOpen] = useState(false);
  const handleOpen = useCallback(() => setOpen(true), []);
  const handleClose = useCallback(() => setOpen(false), []);

  const { feedbackList } = useFeedback();

  const { onSelectFeedback, selectedFeedback } = useSelectFeedback();
  const onClickForm = useCallback(
    (id: number) => {
      onSelectFeedback({ id, feedbackList, handleOpen });
    },
    [feedbackList, onSelectFeedback, handleOpen]
  );

  useEffect(() => getFeedbackList(), [getFeedbackList]);

  return (
    <>
      <Grid
        container
        direction="row"
        justifyContent="center"
        alignItems="stretch"
        spacing={4}
      >
        {itemsByState.map((item) => (
          <Grid item xs={12} key={item.status}>
            {loading ? (
              <Box
                component="div"
                sx={{
                  display: 'inline',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
              >
                <CircularProgress
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                />
              </Box>
            ) : (
              <Card>
                <CardHeader title={item.title} />
                <Divider />
                <List disablePadding>
                  {feedbackList.map((obj) => {
                    if (obj.status == item.status)
                      return (
                        <ListItem
                          divider
                          sx={{
                            py: 2
                          }}
                          key={obj.id}
                        >
                          <ListItemButton onClick={() => onClickForm(obj.id)}>
                            <ListItemAvatar>{item.avatar}</ListItemAvatar>
                            <ListItemText
                              primary={
                                <>
                                  <Text color="secondary">{`[#${obj.id}]`}</Text>
                                  <Text color="black">{`${obj.subject}`}</Text>
                                </>
                              }
                              primaryTypographyProps={{
                                variant: 'body1',
                                fontWeight: 'bold',
                                color: 'textPrimary',
                                gutterBottom: true,
                                noWrap: true
                              }}
                              secondary={
                                <Text color={item.color}>{obj.startDate}</Text>
                              }
                              secondaryTypographyProps={{
                                variant: 'body2',
                                noWrap: true
                              }}
                            />
                          </ListItemButton>
                        </ListItem>
                      );
                  })}
                </List>
              </Card>
            )}
          </Grid>
        ))}
      </Grid>
      <FeedbackDetailModal
        isOpen={open}
        onClose={handleClose}
        feedback={selectedFeedback}
      />
    </>
  );
};

export default FeedbackList;
