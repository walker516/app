import React from 'react';
import SwaggerUI, { SwaggerUIProps } from 'swagger-ui-react';
import 'swagger-ui-react/swagger-ui.css';
import { Box } from '@mui/material';

const SwaggerUIWrapper: React.FC<SwaggerUIProps> = (props) => {
  return (
    <Box>
      <SwaggerUI
        url="https://petstore.swagger.io/v2/swagger.json" // Replace with your Swagger JSON endpoint
        docExpansion="list"
        deepLinking={true}
        defaultModelsExpandDepth={0}
        {...props} // Pass any additional Swagger UI props
      />
    </Box>
  );
};

export default SwaggerUIWrapper;
