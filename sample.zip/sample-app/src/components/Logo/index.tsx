import { Link } from 'react-router-dom';
import {
  Box,
  Tooltip,
  styled,
  useTheme,
  Typography,
  alpha,
  Card,
  Stack,
  Divider
} from '@mui/material';

const LogoWrapper = styled(Link)(
  ({ theme }) => `
        color: ${theme.palette.text.primary};
        display: flex;
        text-decoration: none;
        width: 145px;
        margin: 0 auto;
        font-weight: ${theme.typography.fontWeightBold};
`
);

const TypographyH1 = styled(Typography)(
  ({ theme }) => `
    font-size: ${theme.typography.pxToRem(17)};
`
);

const TypographyH2 = styled(Typography)(
  ({ theme }) => `
    font-size: ${theme.typography.pxToRem(10)};
`
);

const CardWrapper = styled(Card)(
  ({ theme }) => `
      background: ${alpha(theme.colors.alpha.white[10], 0.9)};
  `
);

function Logo() {
  const theme = useTheme();
  return (
    <Tooltip title={'top'} arrow>
      <LogoWrapper to="/overview">
        <CardWrapper>
          <Stack
            direction="column"
            divider={
              <Divider
                sx={{
                  background: `${theme.colors.success.main}`
                }}
                orientation="horizontal"
                flexItem
              />
            }
            textAlign="center"
            px={1}
            py={1}
          >
            <TypographyH1 variant="h2" color="text.secondary" gutterBottom>
              共有DB
            </TypographyH1>
            <Box display="flex" alignItems="center" justifyContent="center">
              <TypographyH2
                color="text.primary"
                variant="h3"
                sx={{ fontStyle: 'italic' }}
              >
                Various Basic Data Base
              </TypographyH2>
            </Box>
          </Stack>
        </CardWrapper>
      </LogoWrapper>
    </Tooltip>
  );
}

export default Logo;
