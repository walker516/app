export type TableDef = {
  id: string;
  name: string;
  isGrid: boolean;
  ancestors?: string[];
  children?: TableDef[];
};
