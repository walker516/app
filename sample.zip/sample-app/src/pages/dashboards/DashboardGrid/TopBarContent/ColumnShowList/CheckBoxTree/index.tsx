import { FC, useLayoutEffect, useMemo } from 'react';
import { TreeItem, treeItemClasses, TreeView } from '@mui/lab';
import { Checkbox, FormControlLabel, styled } from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';

import { useColDefConverter } from 'src/hooks/useColDefConverter';
import { ColumnTree } from 'src/types/columnTree';

const StyledTreeItemRoot = styled(TreeItem)(({ theme }) => ({
  color: theme.palette.text.secondary,
  [`& .${treeItemClasses.content}`]: {
    color: theme.palette.text.secondary,
    borderTopRightRadius: theme.spacing(2),
    borderBottomRightRadius: theme.spacing(2),
    paddingRight: theme.spacing(1),
    fontWeight: theme.typography.fontWeightMedium,
    '&.Mui-expanded': {
      fontWeight: theme.typography.fontWeightRegular
    },
    '&:hover': {
      backgroundColor: theme.palette.action.hover
    },
    '&.Mui-focused, &.Mui-selected, &.Mui-selected.Mui-focused': {
      backgroundColor: `var(--tree-view-bg-color, ${theme.palette.action.selected})`,
      color: 'var(--tree-view-color)'
    },
    [`& .${treeItemClasses.label}`]: {
      fontWeight: 'inherit',
      color: 'inherit'
    }
  },
  [`& .${treeItemClasses.group}`]: {
    marginLeft: 10,
    [`& .${treeItemClasses.content}`]: {
      paddingLeft: theme.spacing(2)
    }
  }
}));

const CheckBoxTree: FC = () => {
  const { columnTree, pullColumnTree, putColumnTree, selected, setSelected } =
    useColDefConverter();

  const selectedSet = useMemo(() => new Set(selected), [selected]);

  const parentMap = useMemo(() => {
    return goThroughAllNodes(columnTree);
  }, [selected]);

  // console.log('parentMAp', parentMap);

  function goThroughAllNodes(nodes: ColumnTree, map: Record<string, any> = {}) {
    if (!nodes.children) {
      return null;
    }

    map[nodes.id] = getAllChild(nodes).splice(1);

    for (let childNode of nodes.children) {
      goThroughAllNodes(childNode, map);
    }

    return map;
  }

  // Get all children from the current node.
  function getAllChild(
    childNode: ColumnTree | null,
    collectedNodes: any[] = []
  ) {
    if (childNode === null) return collectedNodes;

    collectedNodes.push(childNode.id);

    if (Array.isArray(childNode.children)) {
      for (const node of childNode.children) {
        getAllChild(node, collectedNodes);
      }
    }

    return collectedNodes;
  }

  const getChildById = (nodes: ColumnTree, id: string) => {
    let array: string[] = [];
    let path: string[] = [];

    // recursive DFS
    function getNodeById(node: ColumnTree, id: string, parentsPath: string[]) {
      let result = null;

      if (node.id === id) {
        return node;
      } else if (Array.isArray(node.children)) {
        for (let childNode of node.children) {
          result = getNodeById(childNode, id, parentsPath);

          if (!!result) {
            parentsPath.push(node.id);
            return result;
          }
        }

        return result;
      }

      return result;
    }

    const nodeToToggle = getNodeById(nodes, id, path);
    // console.log(path);

    return { childNodesToToggle: getAllChild(nodeToToggle, array), path };
  };

  function getOnChange(checked: boolean, nodes: ColumnTree) {
    const { childNodesToToggle, path } = getChildById(columnTree, nodes.id);
    // console.log('childNodesToChange', { childNodesToToggle, checked });

    let array = checked
      ? [...selected, ...childNodesToToggle]
      : selected
          .filter((value) => !childNodesToToggle.includes(value))
          .filter((value) => !path.includes(value));

    array = array.filter((v, i) => array.indexOf(v) === i);

    setSelected(array);
    putColumnTree(array);
  }

  const renderTree = (nodes: ColumnTree) => {
    const allSelectedChildren: boolean = parentMap[nodes.id]?.every(
      (childNodeId: string) => selectedSet.has(childNodeId)
    );
    const checked: boolean =
      selectedSet.has(nodes.id) || allSelectedChildren || false;

    const indeterminate =
      parentMap[nodes.id]?.some((childNodeId: string) =>
        selectedSet.has(childNodeId)
      ) || false;

    if (allSelectedChildren && !selectedSet.has(nodes.id)) {
      setSelected([...selected, nodes.id]);
    }

    return (
      <StyledTreeItemRoot
        key={nodes.id}
        nodeId={nodes.id}
        label={
          <FormControlLabel
            control={
              <Checkbox
                checked={checked}
                indeterminate={!checked && indeterminate}
                onChange={(event) =>
                  getOnChange(event.currentTarget.checked, nodes)
                }
                onClick={(e) => e.stopPropagation()}
              />
            }
            label={<>{nodes.name}</>}
            key={nodes.id}
          />
        }
      >
        {Array.isArray(nodes.children)
          ? nodes.children.map((node) => renderTree(node))
          : null}
      </StyledTreeItemRoot>
    );
  };

  useLayoutEffect(() => {
    pullColumnTree();
  }, [pullColumnTree]);

  return (
    <TreeView
      defaultCollapseIcon={<ExpandMoreIcon />}
      defaultExpandIcon={<ChevronRightIcon />}
      defaultExpanded={['0-0']}
    >
      {renderTree(columnTree)}
    </TreeView>
  );
};
export default CheckBoxTree;
