import { FC, useRef, useState } from 'react';
import {
  Box,
  Divider,
  Drawer,
  IconButton,
  Tooltip,
  useTheme
} from '@mui/material';
import ViewColumnIcon from '@mui/icons-material/ViewColumn';

import CheckBoxTree from './CheckBoxTree';

const ColumnShowList: FC = () => {
  const theme = useTheme();
  const ref = useRef<any>(null);
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  return (
    <>
      <Tooltip arrow title="Column Show/Hide">
        <IconButton color="primary" onClick={handleDrawerToggle}>
          <ViewColumnIcon />
        </IconButton>
      </Tooltip>
      <Drawer
        sx={{
          display: { xs: 'none', md: 'flex' }
        }}
        variant="temporary"
        anchor={theme.direction === 'rtl' ? 'left' : 'right'}
        open={mobileOpen}
        onClose={handleDrawerToggle}
        elevation={9}
      >
        <Box
          sx={{
            minWidth: 360
          }}
          p={2}
        >
          <Divider
            sx={{
              my: 3
            }}
          />
          <CheckBoxTree />
        </Box>
      </Drawer>
    </>
  );
};
export default ColumnShowList;
