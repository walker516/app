import Scrollbar from 'src/components/Scrollbar';

import {
  Box,
  Button,
  darken,
  Divider,
  Drawer,
  styled,
  useTheme
} from '@mui/material';

import SidebarMenu from './SidebarMenu';
import Logo from 'src/components/Logo';
import { useSidebar } from 'src/contexts/SidebarProvider';
import { PRODUCTION_VBDB2_URL, TEST_VBDB2_URL } from 'src/utils/url';
import { useCookies } from 'react-cookie';

const SidebarWrapper = styled(Box)(
  ({ theme }) => `
        width: ${theme.sidebar.width};
        min-width: ${theme.sidebar.width};
        color: ${theme.colors.alpha.trueWhite[70]};
        position: relative;
        z-index: 7;
        height: 100%;
`
);

const TopSection = styled(Box)(
  ({ theme }) => `
        margin: ${theme.spacing(2)};
`
);

function Sidebar() {
  const { sidebarToggle, toggleSidebar } = useSidebar();
  const closeSidebar = () => toggleSidebar();
  const theme = useTheme();
  const [cookies] = useCookies();

  return (
    <>
      <Drawer
        sx={{
          boxShadow: `${theme.sidebar.boxShadow}`
        }}
        anchor={theme.direction === 'rtl' ? 'right' : 'left'}
        open={sidebarToggle}
        onClose={closeSidebar}
        variant="temporary"
        elevation={9}
      >
        <SidebarWrapper
          sx={{
            background:
              theme.palette.mode === 'dark'
                ? theme.colors.alpha.white[100]
                : darken(theme.colors.alpha.black[100], 0.5),
            boxShadow:
              theme.palette.mode === 'dark' ? theme.sidebar.boxShadow : 'none'
          }}
        >
          <Scrollbar>
            <TopSection>
              <Box
                sx={{
                  width: 52
                }}
              >
                <Logo />
              </Box>
              <Divider
                sx={{
                  my: theme.spacing(1),
                  mx: theme.spacing(1),
                  background: theme.colors.alpha.trueWhite[10]
                }}
              />
            </TopSection>
            <SidebarMenu />
            <Divider
              sx={{
                background: theme.colors.alpha.trueWhite[10]
              }}
            />
            <Box p={2}>
              <Button
                href={
                  cookies['ENV'] === 'production'
                    ? PRODUCTION_VBDB2_URL
                    : TEST_VBDB2_URL
                }
                target="_blank"
                rel="noopener noreferrer"
                variant="contained"
                size="small"
                fullWidth
              >
                現UI
              </Button>
            </Box>
          </Scrollbar>
        </SidebarWrapper>
      </Drawer>
    </>
  );
}

export default Sidebar;
