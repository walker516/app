import {
  createContext,
  Dispatch,
  ReactNode,
  SetStateAction,
  useContext,
  useEffect,
  useState
} from 'react';
import { ColDef, ColGroupDef } from 'ag-grid-community';

import { useGroup } from './GroupProvider';
import { useApiTableList } from 'src/hooks/vbdb2/useApiTableList';
import { TableDef } from 'src/types/tableDef';

type TableContextType = {
  targetTable: TableDef | null;
  columnDef: (ColDef | ColGroupDef)[];
  pinnedUnitData: any;
  setTargetTable: Dispatch<SetStateAction<TableDef | null>>;
  setColumnDef: Dispatch<SetStateAction<(ColDef | ColGroupDef)[]>>;
  setPinnedUnitData: Dispatch<SetStateAction<any>>;
};

// eslint-disable-next-line @typescript-eslint/no-redeclare
const TargetTableContext = createContext<TableContextType>(
  {} as TableContextType
);

type Props = {
  children: ReactNode;
};

export const DataGridProvider = (props: Props) => {
  const { children } = props;
  const { groupId, groupMobileOpen, setGroupMobileOpen } = useGroup();
  const { getTableDefs: getGridDefs } = useApiTableList();
  useEffect(() => {
    setGroupMobileOpen(!groupMobileOpen);
    getGridDefs(groupId);
  }, [groupId]);

  const [targetTable, setTargetTable] = useState<TableDef | null>({
    id: '',
    isGrid: true,
    name: ''
  });

  const [columnDef, setColumnDef] = useState<(ColDef | ColGroupDef)[]>([]);
  const [pinnedUnitData, setPinnedUnitData] = useState<any>();

  return (
    <TargetTableContext.Provider
      value={{
        targetTable,
        columnDef,
        pinnedUnitData,
        setTargetTable,
        setColumnDef,
        setPinnedUnitData
      }}
    >
      {children}
    </TargetTableContext.Provider>
  );
};

export const useTargetTable = (): TableContextType =>
  useContext(TargetTableContext);
