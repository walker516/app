import { useCallback, useState } from 'react';

import { Table } from 'src/types/api/table';
import { useAxiosVbdb2Instance } from './useAxiosVbdb2Instance';
import apiTableList from 'src/db/apiTableList.json';
import { TableDef } from 'src/types/tableDef';

export const useApiTableList = () => {
  const [TableDefs, setTableDefs] = useState<TableDef[]>([]);
  const [loading, setLoading] = useState(false);
  const axiosVbdb2Instance = useAxiosVbdb2Instance();

  const mapTableDef = (props: Table): TableDef => {
    const id = props.table_id;
    const name = props.name;
    const isGrid = props.type === 'T';
    const children = props.children?.map(mapTableDef);
    return { id, name, isGrid, children };
  };

  const getTableDefs = useCallback(async (groupId: 'E' | 'F' | 'A' | 'C') => {
    console.log('List Group-Items: ', groupId);
    if (!groupId) return;
    setLoading(true);

    axiosVbdb2Instance
      .get<Table[]>(`/groups/${groupId}`)
      .then(async (res) => {
        const data: TableDef[] = res.data.map(mapTableDef);

        setTableDefs(data);
      })
      .catch((error) => {
        console.log(error);
      })
      .finally(() => setLoading(false));
    const tmp: Table[] = apiTableList;
    try {
      const data: TableDef[] = tmp.map(mapTableDef);
      setTableDefs(data);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  }, []);

  return { getTableDefs, TableDefs, loading };
};
