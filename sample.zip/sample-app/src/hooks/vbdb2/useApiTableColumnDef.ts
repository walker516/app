import { useCallback } from 'react';
import { ColDef, ColGroupDef } from 'ag-grid-community';

import { useTargetTable } from 'src/contexts/DataGridProvider';
import { useAxiosVbdb2Instance } from './useAxiosVbdb2Instance';

import apiTableColumnDefs from 'src/db/apiTableColumnDef.json';
import { TableColumn, TableColumnGroup } from 'src/types/api/tableColumn';

type Obj = Record<string, any>;

export const useApiTableColumnDef = () => {
  const { setColumnDef, setPinnedUnitData } = useTargetTable();
  const axiosVbdb2Instance = useAxiosVbdb2Instance();

  const mapColumnDefs = (
    props: TableColumn | TableColumnGroup
  ): ColDef | ColGroupDef => {
    if ('children' in props) {
      return {
        headerName: props.name,
        groupId: props.group_id,
        children: props.children.map(mapColumnDefs).filter(Boolean)
      };
    } else {
      const valueFormatter = (params) => {
        const regexp = /^NUM(\d)$/;

        if (regexp.test(props.type)) {
          const value = parseFloat(params.value);

          if (isNaN(value)) {
            return params.value;
          } else {
            const extractNumber = (type: string) => {
              const match = type.match(regexp);
              return parseInt(match[1]);
            };

            const formatOptions = {
              minimumFractionDigits: extractNumber(props.type),
              maximumFractionDigits: extractNumber(props.type)
            };

            return new Intl.NumberFormat('en-US', formatOptions).format(value);
          }
        } else {
          return params.value;
        }
      };
      return {
        headerName: props.name,
        field: props.column_id,
        hide: props.hidden,
        valueFormatter
      };
    }
  };

  const pinnedUnitData: Obj = {};
  const mapPinnedUnit = (props: TableColumn | TableColumnGroup) => {
    if ('children' in props) {
      props.children.forEach(mapPinnedUnit);
    } else {
      pinnedUnitData[props.column_id] = props.unit;
    }
  };

  const getAgColumnDef = useCallback((tableId: string) => {
    console.log('List Column-Definitions: ', tableId);
    if (!tableId || tableId == '') return;

    // axiosVbdb2Instance
    //   .get<(TableColumn | TableColumnGroup)[]>(`/tables/${tableId}/columnDefs`)
    //   .then(async (res) => {
    //     const agColumnDef: (ColDef | ColGroupDef)[] = res.data
    //       .map(mapColumnDefs)
    //       .filter(Boolean);
    //     if (!('children' in agColumnDef[0])) {
    //       agColumnDef[0].pinned = 'left';
    //       agColumnDef[0].lockPinned = true;
    //       agColumnDef[0].cellClass = 'lock-pinned';
    //     }
    //     setColumnDef(agColumnDef);

    //     res.data.forEach(mapPinnedUnit);
    //     setPinnedUnitData(pinnedUnitData);
    //   })
    //   .catch((error) => {
    //     console.log(error);
    //   });

    const tmp: (TableColumn | TableColumnGroup)[] = apiTableColumnDefs;
    const agColumnDef: (ColDef | ColGroupDef)[] = tmp
      .map(mapColumnDefs)
      .filter(Boolean);
    if (!('children' in agColumnDef[0])) {
      agColumnDef[0].pinned = 'left';
      agColumnDef[0].lockPinned = true;
      agColumnDef[0].cellClass = 'lock-pinned';
    }
    setColumnDef(agColumnDef);

    tmp.forEach(mapPinnedUnit);
    setPinnedUnitData(pinnedUnitData);
  }, []);
  return {
    getAgColumnDef
  };
};
