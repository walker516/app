import { Navigate } from 'react-router-dom';
import { RouteObject, useRoutes } from 'react-router';

import PureLayout from 'src/layouts/PureLayout';
import BaseLayout from 'src/layouts/BaseLayout';
import Overview from 'src/pages/overview';
import DashboardGrid from 'src/pages/dashboards/DashboardGrid';
import Feedback from 'src/pages/others/Feedback';
import Maintenance from 'src/pages/management/Maintenance';

const routes: RouteObject[] = [
  {
    path: '',
    element: <PureLayout />,
    children: [
      {
        path: `/`,
        element: <Overview />
      },
      {
        path: `overview`,
        element: <Navigate to="/" replace />
      }
    ]
  },
  {
    path: 'dashboards',
    element: <BaseLayout />,
    children: [
      {
        path: '',
        element: <Navigate to="frame" replace />
      },
      {
        path: 'frame',
        element: <DashboardGrid groupId="F" />
      },
      {
        path: 'engine',
        element: <DashboardGrid groupId="E" />
      },
      {
        path: 'research',
        element: <DashboardGrid groupId="A" />
      },
      {
        path: 'others',
        element: <DashboardGrid groupId="C" />
      }
    ]
  },
  {
    path: 'others',
    element: <BaseLayout />,
    children: [
      {
        path: '',
        element: <Navigate to="feedback" replace />
      },
      {
        path: 'feedback',
        element: <Feedback />
      }
    ]
  },
  {
    path: 'management',
    element: <PureLayout />,
    children: [
      {
        path: '',
        element: <Navigate to="maintenance" replace />
      },
      {
        path: 'maintenance',
        element: <Maintenance />
      }
    ]
  },
  {
    path: '*',
    element: <Overview />
  }
];

export const Router = () => {
  const content = useRoutes(routes);
  return <>{content}</>;
};
