//vbdb2

export const PRODUCTION_VBDB2_API_URL =
  'http://hgaap02.a.rd.honda.co.jp:7041/vbdb2-webservice/api/v2';

// export const TEST_VBDB2_API_URL =
//   'http://hgaap02t.a.rd.honda.co.jp:7041/vbdb2-webservice/api/v2';
export const TEST_VBDB2_API_URL = 'http:test.com';

export const TEST_VBDB2_API_DOCS_URL =
  'http://hgaap02t.a.rd.honda.co.jp:7041/vbdb2-webservice/swagger/ui/index.html?urls.primaryName=integra';

export const PRODUCTION_VBDB2_URL =
  'http://hgaweb.a.rd.honda.com/integra_ebom/vbdb/vbdb2?sTopLoginP=true';

export const TEST_VBDB2_URL =
  'http://hgaweb.a.rd.honda.com/integra_ebom/vbdb/vbdb2?sTopLoginP=true';

// redmine

export const PRODUCTION_REDMINE_API_URL = 'http://hga-redsvn01pz/redmine';

// export const TEST_REDMINE_API_URL = 'http://hga-redsvn01pz:81/redmine';
export const TEST_REDMINE_API_URL = 'http:test.com';

export const REDMINE_API_KEY = '3b352811736ad29309aabcfb2705a339657e6c61';

// others

export const TEST_USER_ID = 'J0134484';

export const ENG_UI_URL = 'http://172.28.34.145:183/';
