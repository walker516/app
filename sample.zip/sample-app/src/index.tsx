import ReactDOM from 'react-dom';

import 'nprogress/nprogress.css';
import App from 'src/App';
import { CookiesProvider } from 'react-cookie';

ReactDOM.render(
  <CookiesProvider>
    <App />
  </CookiesProvider>,
  document.getElementById('root')
);
