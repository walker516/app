export type IssueTracker = {
  id: number; // [不具合]: 1, [要望]: 2, [その他]: 3
  name: string;
};

export type IssueStatus = {
  id: number; // [新規]: 1, [進行中]: 2, [テスト中]: 9, [終了]: 5
  name: string;
};

export type Issue = {
  id: number;
  tracker: IssueTracker;
  status: IssueStatus;
  subject: string;
  description: string;
  start_date: string;
  custom_fields: { id: number; value: string }[]; // [user_id]: 34
  project_id: string;
  attachments: { filename: string }[];
};

export type ListIssues = {
  issues: Issue[];
};

export type PostIssue = {
  issue: Omit<Issue, 'id' | 'status' | 'attachments'> & {
    trackerId?: number;
    customFields?: { id: number; name: string }[];
    uploads?: { token?: string; filename?: string };
  };
};
