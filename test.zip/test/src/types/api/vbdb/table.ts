export type Table = {
  children?: Table[];
  table_id: string;
  type: string;
  name: string;
  group_id?: string;
  ancestors?: string[];
  table_type?: string;
};
