export type TableRowData = {
  row_id: string;
  cells?: { column_id: string; value: string }[];
};
