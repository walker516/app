export enum Group {
  Frame = 'Frame',
  Engine = 'Engine',
  Research = 'Research',
  Other = 'Other'
}

interface GroupData {
  groupId: string;
  name: string;
  color:
    | 'inherit'
    | 'info'
    | 'primary'
    | 'secondary'
    | 'success'
    | 'error'
    | 'warning';
}

const Groups: Record<Group, GroupData> = {
  [Group.Frame]: { groupId: 'F', name: '車体系', color: 'primary' },
  [Group.Engine]: { groupId: 'E', name: 'ENG系', color: 'info' },
  [Group.Research]: { groupId: 'A', name: '研究系', color: 'success' },
  [Group.Other]: { groupId: 'C', name: '他社', color: 'secondary' }
};

export const getGroupId = (group: Group): string => {
  return Groups[group].groupId;
};

export const getGroupName = (group: Group): string => {
  return Groups[group].name;
};

export const getGroupColor = (
  group: Group
):
  | 'inherit'
  | 'info'
  | 'primary'
  | 'secondary'
  | 'success'
  | 'error'
  | 'warning' => {
  return Groups[group].color;
};
