// TODO: Enum型を利用することを検討する - by Oka
export enum FeedbackTracker {
  Issue = '1', // 不具合
  Request = '2', // 要望
  Other = '3' // その他
}

export enum FeedbackStatus {
  New = '1', // 新規
  InProgress = '2', // 進行中
  InTest = '9', // テスト中
  Completed = '5' // 終了
}

export type Feedback = {
  id?: number;
  userId: string;
  tracker: string;
  status: string;
  subject: string;
  description?: string;
  startDate: string;
  fileName?: string;
};

export type PostFeedback = Omit<
  Feedback,
  'id' | 'status' | 'fileName' | 'startDate'
> & {
  postFileData?: File;
};
