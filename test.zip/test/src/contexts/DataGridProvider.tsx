import {
  createContext,
  Dispatch,
  ReactNode,
  SetStateAction,
  useContext,
  useEffect,
  useState
} from 'react';
import { ColDef, ColGroupDef } from 'ag-grid-community';

import { useGroup } from './GroupProvider';
import { useApiTableList } from 'src/hooks/vbdb2/useApiTableList';
import { TableDef } from 'src/types/tableDef';
import { getGroupId } from 'src/types/group';

type TableContextType = {
  targetTable: TableDef | null;
  columnDef: (ColDef | ColGroupDef)[];
  pinnedUnitData: any;
  setTargetTable: Dispatch<SetStateAction<TableDef | null>>;
  setColumnDef: Dispatch<SetStateAction<(ColDef | ColGroupDef)[]>>;
  setPinnedUnitData: Dispatch<SetStateAction<any>>;
};

// eslint-disable-next-line @typescript-eslint/no-redeclare
const TargetTableContext = createContext<TableContextType>(
  {} as TableContextType
);

type Props = {
  children: ReactNode;
};

export const DataGridProvider = (props: Props) => {
  const { children } = props;
  const { group, groupMobileOpen, setGroupMobileOpen } = useGroup();
  const { getTableDefs: getGridDefs } = useApiTableList();

  useEffect(() => {
    setGroupMobileOpen(!groupMobileOpen);
    getGridDefs(getGroupId(group));
  }, [group]);
  // TODO: フックの依存関係リストを再検討する（現状: group または groupMobileOpen の変更時に都度 TableTree が再描画されている） - by Oka

  const [targetTable, setTargetTable] = useState<TableDef | null>({
    id: '',
    isGrid: true,
    name: ''
  });

  const [columnDef, setColumnDef] = useState<(ColDef | ColGroupDef)[]>([]);
  const [pinnedUnitData, setPinnedUnitData] = useState<any>();

  return (
    <TargetTableContext.Provider
      value={{
        targetTable,
        columnDef,
        pinnedUnitData,
        setTargetTable,
        setColumnDef,
        setPinnedUnitData
      }}
    >
      {children}
    </TargetTableContext.Provider>
  );
};

export const useTargetTable = (): TableContextType =>
  useContext(TargetTableContext);
