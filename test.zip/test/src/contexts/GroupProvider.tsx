import {
  createContext,
  useContext,
  useState,
  ReactNode,
  Dispatch,
  SetStateAction
} from 'react';

import { Group } from 'src/types/group';

type GroupContextType = {
  group: Group;
  groupMobileOpen: boolean | null;
  setGroupMobileOpen: Dispatch<SetStateAction<boolean | null>>;
  toggleGroupSidebar: () => void;
  closeGroupSidebar: () => void;
};

type Props = {
  children: ReactNode;
  group: Group;
};

const GroupContext = createContext<GroupContextType>({} as GroupContextType);

export const GroupProvider = ({ children, group }: Props) => {
  const [groupMobileOpen, setGroupMobileOpen] = useState<boolean | null>(false);

  const toggleGroupSidebar = () => {
    setGroupMobileOpen((prevGroupMobileOpen) => !prevGroupMobileOpen);
  };

  const closeGroupSidebar = () => {
    setGroupMobileOpen(false);
  };

  return (
    <GroupContext.Provider
      value={{
        group,
        groupMobileOpen,
        setGroupMobileOpen,
        toggleGroupSidebar,
        closeGroupSidebar
      }}
    >
      {children}
    </GroupContext.Provider>
  );
};

export const useGroup = (): GroupContextType => useContext(GroupContext);
