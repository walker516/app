import { FC } from 'react';
import { Box, Container, Link, Typography, styled } from '@mui/material';

import { APP_NAME_JA, ENG_UI_URL } from 'src/utils/url';

const FooterWrapper = styled(Container)(
  ({ theme }) => `
        margin-top: ${theme.spacing(0.5)};
`
);

const Footer: FC = () => {
  return (
    <FooterWrapper>
      <Box
        pb={0.5}
        display="flex"
        alignItems="center"
        justifyContent="space-between"
      >
        <Box>
          <Typography variant="subtitle1">
            &copy; {`2023 - ${APP_NAME_JA}`}
          </Typography>
        </Box>
        <Typography variant="subtitle1">
          Ref:{' '}
          <Link href={ENG_UI_URL} target="_blank">
            ENG_UI
          </Link>
        </Typography>
      </Box>
    </FooterWrapper>
  );
};

export default Footer;
