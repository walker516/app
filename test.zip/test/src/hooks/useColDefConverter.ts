import { ColDef, ColGroupDef } from 'ag-grid-community';
import { useCallback, useState } from 'react';
import { useTargetTable } from 'src/contexts/DataGridProvider';
import { ColumnTree } from 'src/types/columnTree';

export const useColDefConverter = () => {
  const { columnDef, setColumnDef } = useTargetTable();
  const [selected, setSelected] = useState<string[]>([]);
  const [columnTree, setColumnTree] = useState<ColumnTree>({
    name: 'Sellect All',
    id: '0-0',
    children: []
  });

  // カラムツリー用にデータ変換する関数
  const pullColumnTree = useCallback(() => {
    const showData: string[] = [];

    const checkShowChildren = (props: (ColDef | ColGroupDef)[]) => {
      return props.every((prop) => {
        if ('children' in prop) {
          return checkShowChildren(prop.children);
        } else {
          if (prop.hide) {
            return false;
          } else {
            showData.push(prop.field);
          }
        }
        return true;
      });
    };

    // showDataの登録関数とマッピングを関数として分割することを検討する - by Oka
    const mapShowData = (props: (ColDef | ColGroupDef)[]) => {
      return props.map((prop) => {
        if ('children' in prop) {
          if (checkShowChildren(prop.children)) {
            showData.push(prop.groupId);
          }
          return {
            name: prop.headerName,
            id: prop.groupId,
            children: mapShowData(prop.children)
          };
        } else {
          if (!prop.hide) {
            showData.push(prop.field);
          }
          return {
            name: prop.headerName,
            id: prop.field
          };
        }
      });
    };

    if (checkShowChildren(columnDef)) {
      showData.push('0-0');
    }

    const changedColumnTree: ColumnTree = {
      name: 'Sellect All',
      id: '0-0',
      children: mapShowData(columnDef)
    };

    setColumnTree(changedColumnTree);
    setSelected(showData);
  }, []);

  // AgGridにカラムツリーのデータを適用する関数
  const putColumnTree = useCallback(
    (array: string[]) => {
      const mapColumnDefs = (props: ColDef | ColGroupDef) => {
        if ('children' in props) {
          return {
            headerName: props?.headerName,
            groupId: props.groupId,
            children: props.children.map(mapColumnDefs).filter(Boolean)
          };
        } else {
          return {
            headerName: props?.headerName,
            field: props?.field,
            hide: !array.some((p) => p === props.field),
            valueFormatter: props.valueFormatter
          };
        }
      };

      const changedColumnDef = columnDef.map(mapColumnDefs);
      const leftLockPinned = (
        columnDef: (ColDef<any> | ColGroupDef<any>)[]
      ) => {
        if (!('children' in columnDef[0])) {
          columnDef[0].pinned = 'left';
          columnDef[0].lockPinned = true;
          columnDef[0].cellClass = 'lock-pinned';
        } else {
          leftLockPinned(columnDef[0].children);
          console.log('children');
        }
      };
      leftLockPinned(changedColumnDef);
      setColumnDef(changedColumnDef);
    },
    [selected]
  );

  return {
    selected,
    setSelected,
    columnTree,
    setColumnTree,
    pullColumnTree,
    putColumnTree
  };
};
