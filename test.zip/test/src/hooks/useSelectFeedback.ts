import { useCallback, useState } from 'react';
import { Feedback } from 'src/types/feedback';

type Props = {
  id: number;
  feedbackList: Feedback[];
  handleOpen: () => void;
};

export const useSelectFeedback = () => {
  const [selectedFeedback, setSelectedFeedback] = useState<Feedback>();

  const onSelectFeedback = useCallback((props: Props) => {
    const { id, feedbackList: feedbackList, handleOpen } = props;
    const targetFeedback = feedbackList.find((obj) => obj.id === id);
    if (!targetFeedback) {
      return;
    } else {
      setSelectedFeedback(targetFeedback);
      handleOpen();
    }
  }, []);
  return { onSelectFeedback, selectedFeedback };
};
