import { useCallback, useState } from 'react';
import { useFeedback } from 'src/contexts/FeedbackProvider';
import { ListIssues } from 'src/types/api/redmine/issue';
import { Feedback } from 'src/types/feedback';
import { useAxiosRedmineInstance } from './useAxiosRedmineInstance';

const PROJECT_ID = '642';

function getUserId(customFields: { id: number; value: string }[]): string {
  const userIdProp = customFields.find((prop) => prop.id === 34);
  return userIdProp?.value || '';
}

export const useApiListIssues = () => {
  const [loading, setLoading] = useState<boolean>(false);
  const { setFeedbackList } = useFeedback();
  const axiosRedmineInstance = useAxiosRedmineInstance();

  const getFeedbackList = useCallback(() => {
    console.log('List Issues');
    setLoading(true);

    axiosRedmineInstance
      .get<ListIssues>('/issues.json', {
        params: {
          project_id: PROJECT_ID,
          include: 'attachments',
          status_id: '*'
        }
      })
      .then(async (res) => {
        const data: Array<Feedback> = res.data.issues.map((props) => {
          return {
            id: props.id,
            status: props.status?.id?.toString(),
            tracker: props.tracker?.id?.toString(),
            subject: props.subject,
            description: props.description,
            startDate: props.start_date,
            userId: getUserId(props.custom_fields),
            fileName: props?.attachments[0]?.filename
          };
        });
        setFeedbackList(data);
      })
      .catch((error) => {
        console.log(error);
      })
      .finally(() => setLoading(false));
  }, []);
  return {
    getFeedbackList,
    loading
  };
};
