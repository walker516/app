import { useCallback } from 'react';
import { ColDef, ColGroupDef } from 'ag-grid-community';

import { useTargetTable } from 'src/contexts/DataGridProvider';
import { useAxiosVbdb2Instance } from './useAxiosVbdb2Instance';
import { TableColumn } from 'src/types/api/vbdb/tableColumn';

type Obj = Record<string, any>;
const mapColumns = (arr: TableColumn[]): (ColDef | ColGroupDef)[] => {
  const result: (ColDef | ColGroupDef)[] = [];
  const superGroups: { [key: string]: ColGroupDef } = {};

  for (let i = 0; i < arr.length; i++) {
    const { column_id, name1, name2, name3, type } = arr[i];

    if (!superGroups[name1]) {
      const groupId = `g${result.length + 1}`;
      superGroups[name1] = {
        groupId,
        headerName: name1,
        children: []
      };
      result.push(superGroups[name1]);
    }

    const superGroup = superGroups[name1];
    let subGroup = superGroup.children.find((sub) => sub.headerName === name2);

    if (!subGroup) {
      const groupId = `g${superGroup.groupId}-${
        superGroup.children.length + 1
      }`;
      subGroup = {
        groupId,
        headerName: name2,
        children: []
      };
      superGroup.children.push(subGroup);
    }

    // TODO: 数字以外の変換実装を検討する -by Oka
    const valueFormatter = (params: any) => {
      const regexp = /^NUM(\d)$/;

      if (regexp.test(type)) {
        const value = parseFloat(params.value);

        if (isNaN(value)) {
          return params.value;
        } else {
          const extractNumber = (type: string) => {
            const match = type.match(regexp);
            return parseInt(match[1]);
          };

          const formatOptions = {
            minimumFractionDigits: extractNumber(type),
            maximumFractionDigits: extractNumber(type)
          };

          return new Intl.NumberFormat('en-US', formatOptions).format(value);
        }
      } else {
        return params.value;
      }
    };
    (subGroup as ColGroupDef).children.push({
      field: column_id,
      headerName: name3,
      valueFormatter
    });
  }

  return result;
};
export const useApiTableColumnDef = () => {
  const { setColumnDef, setPinnedUnitData } = useTargetTable();
  const axiosVbdb2Instance = useAxiosVbdb2Instance();

  const pinnedUnitData: Obj = {};

  const getAgColumnDef = useCallback((tableId: string) => {
    console.log('List Columns: ', tableId);
    if (!tableId || tableId === '') return;

    axiosVbdb2Instance
      .get<TableColumn[]>(`/tables/${tableId}/columns`)
      .then(async (res) => {
        const agColumnDef: (ColDef<any> | ColGroupDef<any>)[] = mapColumns(
          res.data
        );
        const leftLockPinned = (
          columnDef: (ColDef<any> | ColGroupDef<any>)[]
        ) => {
          if (!('children' in columnDef[0])) {
            columnDef[0].pinned = 'left';
            columnDef[0].lockPinned = true;
            columnDef[0].cellClass = 'lock-pinned';
          } else {
            leftLockPinned(columnDef[0].children);
            console.log('children');
          }
        };
        leftLockPinned(agColumnDef);
        if (!('children' in agColumnDef[0])) {
          agColumnDef[0].pinned = 'left';
          agColumnDef[0].lockPinned = true;
          agColumnDef[0].cellClass = 'lock-pinned';
        }
        setColumnDef(agColumnDef);

        res.data.forEach(
          (column) => (pinnedUnitData[column.column_id] = column.unit)
        );
        setPinnedUnitData(pinnedUnitData);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  return {
    getAgColumnDef
  };
};
//TODO: tanstack-queryの利用を検討する -by Oka
