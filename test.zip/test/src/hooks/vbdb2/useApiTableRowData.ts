import { useCallback, useState } from 'react';
import { useAxiosVbdb2Instance } from './useAxiosVbdb2Instance';
import { TableRowData } from 'src/types/api/vbdb/tableRowData';

type Obj = Record<string, any>;

export const useApiTableRowData = () => {
  const [agRowData, setAgRowData] = useState<Obj[]>([]);
  const [loading, setLoading] = useState(false);
  const axiosRedmineInstance = useAxiosVbdb2Instance();

  const getAgRowData = useCallback(async (tableId: string) => {
    console.log('List Row-Data: ', tableId);
    if (!tableId || tableId == '') return;

    let pageNum = 1;
    setAgRowData([]);
    setLoading(true);

    while (pageNum > 0) {
      try {
        const res = await axiosRedmineInstance.get<TableRowData[]>(
          `/tables/${tableId}/rows`,
          {
            params: {
              field_mask: 'cells',
              page: pageNum
            }
          }
        );

        const nextLink = res.headers['link'];

        if (typeof nextLink === 'undefined') {
          pageNum = 0;
        } else {
          pageNum++;
        }
        const data = res.data.map((props: TableRowData) => {
          let rowData: Obj = {};
          props.cells.forEach((cell) => {
            rowData[cell.column_id] = cell.value;
          });
          return rowData;
        });

        setAgRowData((prevAgRowData) => [...prevAgRowData, ...data]);
      } catch (error) {
        console.log(error);
        return;
      } finally {
        setLoading(pageNum > 0);
      }
    }
  }, []);

  return {
    getAgRowData,
    agRowData,
    loading
  };
};
// TODO: pageNum の更新時に loading の再レンダリングが発生を防ぐ方法を検討する - by Oka
