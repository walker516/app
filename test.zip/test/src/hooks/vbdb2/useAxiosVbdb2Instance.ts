import axios, { AxiosInstance } from 'axios';
import useCookies from 'react-cookie/cjs/useCookies';
import {
  PRODUCTION_VBDB2_API_URL,
  TEST_VBDB2_API_URL,
  TEST_USER_ID
} from 'src/utils/url';

export const useAxiosVbdb2Instance = () => {
  const [cookies] = useCookies();

  const axiosVbdb2Instance: AxiosInstance = axios.create({
    baseURL:
      cookies['ENV'] === 'production'
        ? PRODUCTION_VBDB2_API_URL
        : TEST_VBDB2_API_URL,
    params: {
      user_id: cookies['ENV'] === undefined ? TEST_USER_ID : cookies['USER_ID'],
      app_name: 'UI'
    }
  });

  return axiosVbdb2Instance;
};
