import { createContext, FC, useState } from 'react';
import { ThemeProvider } from '@mui/material';
import { StylesProvider } from '@mui/styles';
import { useCookies } from 'react-cookie';

import { themeCreator } from './base';

const ThemeContext = createContext((themeName: string): void => {});

export const ThemeProviderWrapper: FC = (props) => {
  const [cookies] = useCookies();
  const curThemeName =
    cookies['ENV'] === 'production' ? 'ProductionTheme' : 'TestTheme';
  const [themeName, _setThemeName] = useState(curThemeName);
  const theme = themeCreator(themeName);
  const setThemeName = (themeName: string): void => {
    localStorage.setItem('appTheme', themeName);
    _setThemeName(themeName);
  };

  return (
    <StylesProvider injectFirst>
      <ThemeContext.Provider value={setThemeName}>
        <ThemeProvider theme={theme}>{props.children}</ThemeProvider>
      </ThemeContext.Provider>
    </StylesProvider>
  );
};

export default ThemeProviderWrapper;
