// VBDB2
export const PRODUCTION_VBDB2_API_URL =
  'http://ahgaap02.a.rd.honda.co.jp:7041/vbdb2-webservice/api/v3';
export const TEST_VBDB2_API_URL =
  'http://ahgaap02t.a.rd.honda.co.jp:7041/vbdb2-webservice/api/v3';
export const TEST_VBDB2_API_DOCS =
  'http://ahgaap02t.a.rd.honda.co.jp:7041/vbdb2-webservice/api/swagger.json';
export const PRODUCTION_VBDB2_URL =
  'http://ahgaweb.a.rd.honda.com/integra_ebom/vbdb/vbdb2?sTopLoginP=true';
export const TEST_VBDB2_URL =
  'http://ahgaweb.a.rd.honda.com/integra_ebom/vbdb/vbdb2?sTopLoginP=true';

// Redmine
export const PRODUCTION_REDMINE_API_URL = 'http://hga-redsvn01pz/redmine';
export const TEST_REDMINE_API_URL = 'http://hga-redsvn01pz:81/redmine';
export const REDMINE_API_KEY = '3b352811736ad29309aabcfb2705a339657e6c61';

// Others
export const APP_NAME_JA = '共有DB Plus';
export const APP_NAME_EN = 'Various Basic Data Base Plus';
export const TEST_USER_ID = 'J0134484';
export const ENG_UI_URL = 'http://172.28.34.145:183/';
