import { Helmet } from 'react-helmet-async';
import { Box, Typography, Container, Divider } from '@mui/material';
import { styled } from '@mui/material/styles';

const MainContent = styled(Box)(
  () => `
      height: 100%;
      display: flex;
      flex: 1;
      overflow: auto;
      flex-direction: column;
      align-items: center;
      justify-content: center;
  `
);

const Error = () => {
  return (
    <>
      <Helmet>
        <title>Error</title>
      </Helmet>
      <MainContent>
        <Container maxWidth="md">
          <Box textAlign="center">
            <Container maxWidth="xs">
              <Typography variant="h2" sx={{ mt: 4, mb: 2 }}>
                The site is experiencing errors
              </Typography>
              <Typography
                variant="h3"
                color="text.secondary"
                fontWeight="normal"
                sx={{ mb: 4 }}
              >
                We apologize for any inconveniences caused
              </Typography>
            </Container>
          </Box>
          <Divider sx={{ my: 4 }} />
        </Container>
      </MainContent>
    </>
  );
};

export default Error;
