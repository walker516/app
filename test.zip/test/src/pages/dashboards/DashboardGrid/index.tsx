import { FC, useRef } from 'react';
import { Box, styled } from '@mui/material';
import { AgGridReact } from 'ag-grid-react';

import Footer from 'src/components/Footer';
import { GroupProvider } from 'src/contexts/GroupProvider';
import { DataGridProvider } from 'src/contexts/DataGridProvider';
import TopBarContent from './TopBarContent';
import AgGrid from './AgGrid';
import { Group } from 'src/types/group';

const RootWrapper = styled(Box)(
  ({ theme }) => `
       height: calc(100vh - ${theme.header.height});
       display: flex;
`
);

const GridWindow = styled(Box)(
  () => `
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
        flex: 1;
`
);

const GridTopBar = styled(Box)(
  ({ theme }) => `
        padding: ${theme.spacing(2)};
        align-items: center;
`
);

type Props = {
  group: Group;
};
// TODO: 機能区の選択状態をprops経由ではなく、contextを使用して保持する方法を検討する - by Oka

const DashboardGrid: FC<Props> = ({ group }) => {
  const gridRef = useRef<AgGridReact>(null);
  return (
    <RootWrapper className="Mui-FixedWrapper">
      <GroupProvider group={group}>
        <DataGridProvider>
          <GridWindow>
            <GridTopBar>
              <TopBarContent gridRef={gridRef} />
            </GridTopBar>
            <Box flex={1}>
              <AgGrid gridRef={gridRef} />
            </Box>
            <Footer />
          </GridWindow>
        </DataGridProvider>
      </GroupProvider>
    </RootWrapper>
  );
};

export default DashboardGrid;
