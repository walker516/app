import { FC, MutableRefObject } from 'react';
import { Box, Typography, styled } from '@mui/material';
import { AgGridReact } from 'ag-grid-react';

import { useTargetTable } from 'src/contexts/DataGridProvider';
import TableOperator from './TableOperator';
import TableListButton from './TableList';

type Props = {
  gridRef: MutableRefObject<AgGridReact<any>>;
};

const TopBarContent: FC<Props> = (props) => {
  const { gridRef } = props;
  const { targetTable } = useTargetTable();
  return (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        maxWidth: 1
      }}
    >
      <Box>
        <TableListButton />
      </Box>
      {targetTable.id == '' || (
        <>
          <Box sx={{ overflow: 'hidden' }}>
            <Typography
              variant="h3"
              component="h3"
              gutterBottom
              overflow="hidden"
              textOverflow="ellipsis"
              noWrap
              sx={{
                fontWeight: 'inherit',
                flexGrow: 1
              }}
            >
              {targetTable.name}
            </Typography>
          </Box>
          <Box>
            <TableOperator gridRef={gridRef} />
          </Box>
        </>
      )}
    </Box>
  );
};

export default TopBarContent;
// TODO: TopBarContentの子コンポーネントに対して、コンポーネント分割を検討する -by Oka
