import { FC, useCallback, useEffect } from 'react';
import { styled } from '@mui/material/styles';
import { Box, CircularProgress, Typography } from '@mui/material';
import TreeView from '@mui/lab/TreeView';
import TreeItem, { TreeItemProps, treeItemClasses } from '@mui/lab/TreeItem';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import ArrowRightIcon from '@mui/icons-material/ArrowRight';
import FolderIcon from '@mui/icons-material/Folder';
import TableChartIcon from '@mui/icons-material/TableChart';

import { useApiTableList } from 'src/hooks/vbdb2/useApiTableList';
import { useGroup } from 'src/contexts/GroupProvider';
import { useTargetTable } from 'src/contexts/DataGridProvider';
import { TableDef } from 'src/types/tableDef';
import { getGroupId } from 'src/types/group';

declare module 'react' {
  interface CSSProperties {
    '--tree-view-color'?: string;
    '--tree-view-bg-color'?: string;
  }
}

type Props = {
  searchQuery: string;
};

type StyledTreeItemProps = TreeItemProps & {
  labelText: string;
  isGrid: boolean;
  ancestors: string[];
};

// TODO: 機能区によってカラー変更を検討する - by Oka
const StyledTreeItemRoot = styled(TreeItem)(({ theme }) => ({
  color: theme.palette.text.secondary,
  [`& .${treeItemClasses.content}`]: {
    color: theme.palette.text.secondary,
    borderTopRightRadius: theme.spacing(2),
    borderBottomRightRadius: theme.spacing(2),
    paddingRight: theme.spacing(1),
    fontWeight: theme.typography.fontWeightMedium,
    '&.Mui-expanded': {
      fontWeight: theme.typography.fontWeightRegular
    },
    '&:hover': {
      backgroundColor: theme.palette.action.hover
    },
    '&.Mui-focused, &.Mui-selected, &.Mui-selected.Mui-focused': {
      backgroundColor: `var(--tree-view-bg-color, ${theme.palette.action.selected})`,
      color: 'var(--tree-view-color)'
    },
    [`& .${treeItemClasses.label}`]: {
      fontWeight: 'inherit',
      color: 'inherit'
    }
  },
  [`& .${treeItemClasses.group}`]: {
    marginLeft: 10,
    [`& .${treeItemClasses.content}`]: {
      paddingLeft: theme.spacing(2)
    }
  }
}));

const StyledTreeItem: FC<StyledTreeItemProps> = ({
  labelText,
  isGrid,
  nodeId,
  ancestors,
  ...other
}) => {
  const { setTargetTable } = useTargetTable();
  const { groupMobileOpen, setGroupMobileOpen } = useGroup();

  const onSelectTable = useCallback(
    (id: string, name: string, ancestors: string[]) => {
      setTargetTable({
        id: id,
        name: name,
        isGrid: true,
        ancestors: ancestors
      });
      setGroupMobileOpen(!groupMobileOpen);
    },
    []
  );

  return (
    <StyledTreeItemRoot
      nodeId={nodeId}
      label={
        <Box
          sx={{ display: 'flex', alignItems: 'center', p: 0.5, pr: 0 }}
          onClick={() => {
            if (isGrid) {
              onSelectTable(nodeId, labelText, ancestors);
            }
          }}
        >
          <Box
            component={isGrid ? TableChartIcon : FolderIcon}
            color="inherit"
            sx={{ mr: 1 }}
          />
          <Typography
            variant="body2"
            sx={{ fontWeight: 'inherit', flexGrow: 1 }}
          >
            {labelText}
          </Typography>
        </Box>
      }
      style={{
        '--tree-view-color': isGrid ? '#1a73e8' : '',
        '--tree-view-bg-color': isGrid ? '#e8f0fe' : ''
      }}
      {...other}
    />
  );
};

const renderTree = (obj: TableDef, ancestors: string[]) => (
  <StyledTreeItem
    key={obj.id}
    nodeId={obj.id}
    labelText={obj.name}
    isGrid={obj.isGrid}
    ancestors={ancestors.concat(obj.id)} // Pass the current node's id to ancestors and concatenate it with the existing ancestors
  >
    {obj.children?.map((child) => renderTree(child, ancestors.concat(obj.id)))}
  </StyledTreeItem>
);

const renderFilteredTree = (
  obj: TableDef,
  ancestors: string[],
  searchQuery: string
) => {
  const matchesSearchQuery = obj.name
    .toLowerCase()
    .includes(searchQuery.toLowerCase());

  const filteredChildren = obj.children?.map((child) =>
    renderFilteredTree(child, ancestors.concat(obj.id), searchQuery)
  );

  const anyDescendantMatches = filteredChildren?.some(Boolean);

  if (matchesSearchQuery || anyDescendantMatches) {
    return (
      <StyledTreeItem
        key={obj.id}
        nodeId={obj.id}
        labelText={obj.name}
        isGrid={obj.isGrid}
        ancestors={ancestors.concat(obj.id)}
        sx={
          !matchesSearchQuery && !anyDescendantMatches
            ? { display: 'none' }
            : undefined
        }
      >
        {filteredChildren}
      </StyledTreeItem>
    );
  }

  return null;
};

const TableTree: FC<Props> = ({ searchQuery }) => {
  const { getTableDefs, TableDefs, loading } = useApiTableList();
  const { group } = useGroup();
  const { targetTable } = useTargetTable();

  useEffect(() => {
    getTableDefs(getGroupId(group));
  }, []);

  return (
    <>
      {loading ? (
        <Box
          component="div"
          sx={{
            display: 'inline',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          <CircularProgress
            sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          />
        </Box>
      ) : (
        <TreeView
          aria-label="list"
          defaultCollapseIcon={<ArrowDropDownIcon />}
          defaultExpandIcon={<ArrowRightIcon />}
          defaultEndIcon={<div style={{ width: 24 }} />}
          defaultExpanded={targetTable.ancestors}
          sx={{ flexGrow: 1, maxWidth: 400, overflowY: 'auto' }}
        >
          {TableDefs?.map((item) => renderFilteredTree(item, [], searchQuery))}
        </TreeView>
      )}
    </>
  );
};

export default TableTree;
