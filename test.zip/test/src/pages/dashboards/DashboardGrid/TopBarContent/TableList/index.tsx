import { FC, useState } from 'react';
import {
  Box,
  Button,
  Divider,
  Drawer,
  Tooltip,
  IconButton,
  useTheme,
  Hidden,
  styled
} from '@mui/material';
import AccountTreeIcon from '@mui/icons-material/AccountTree';

import TableTree from './TableTree';
import { useGroup } from 'src/contexts/GroupProvider';
import SearchBar from './SearchBar';
import { getGroupColor } from 'src/types/group';

const IconButtonToggle = styled(IconButton)(
  ({ theme }) => `
  width: ${theme.spacing(8)};
  background: ${theme.colors.alpha.white[100]};
`
);

const TableListButton: FC = () => {
  const { group, groupMobileOpen, setGroupMobileOpen } = useGroup();
  const theme = useTheme();
  const [searchQuery, setSearchQuery] = useState('');

  const handleDrawerToggle = () => {
    setGroupMobileOpen(!groupMobileOpen);
  };

  return (
    <>
      <Box component="span">
        <Tooltip placement="right-end" title="Table List">
          <IconButtonToggle
            color={getGroupColor(group)}
            onClick={handleDrawerToggle}
          >
            <AccountTreeIcon fontSize="large" />
          </IconButtonToggle>
        </Tooltip>
      </Box>
      <Drawer
        sx={{
          boxShadow: `${theme.sidebar.boxShadow}`
        }}
        variant="temporary"
        anchor={theme.direction === 'rtl' ? 'right' : 'left'}
        open={groupMobileOpen}
        onClose={handleDrawerToggle}
        elevation={9}
      >
        <Box
          sx={{
            minWidth: 360
          }}
          p={2}
        >
          <SearchBar
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
          />
          <Divider
            sx={{
              my: 3
            }}
          />
          <TableTree searchQuery={searchQuery} />
        </Box>
      </Drawer>
    </>
  );
};

export default TableListButton;
