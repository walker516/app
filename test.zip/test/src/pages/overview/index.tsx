import { FC } from 'react';
import { Helmet } from 'react-helmet-async';
import { Box, Container, Card } from '@mui/material';
import { styled } from '@mui/material/styles';

import Hero from './Hero';
import { APP_NAME_JA } from 'src/utils/url';

const OverviewWrapper = styled(Box)(
  () => `
    overflow: auto;
    flex: 1;
    overflow-x: hidden;
    align-items: center;
`
);

const Overview: FC = () => {
  return (
    <OverviewWrapper>
      <Helmet>
        <title>{APP_NAME_JA}</title>
      </Helmet>
      <Container maxWidth="lg">
        <br />
        <Card sx={{ p: 10, mb: 10, borderRadius: 12 }}>
          <Hero />
        </Card>
      </Container>
    </OverviewWrapper>
  );
};

export default Overview;
