import { FC } from 'react';
import {
  Box,
  Card,
  CardContent,
  Divider,
  Grid,
  Modal,
  Typography
} from '@mui/material';

import Text from 'src/components/Text';
import { Feedback } from 'src/types/feedback';

const style = {
  position: 'absolute' as 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)'
};

type Props = {
  feedback: Feedback | undefined;
  isOpen: boolean;
  onClose: () => void;
};

const changeJa = (tracker: string) => {
  switch (tracker) {
    case '1':
      return '不具合';
    case '2':
      return '要望';
    case '3':
      return 'その他(サポート, API関連)';
    default:
      return '存在しないトラッカー';
  }
};

const FeedbackDetailModal: FC<Props> = ({ feedback, isOpen, onClose }) => {
  return (
    <Modal
      keepMounted
      open={isOpen}
      onClose={onClose}
      aria-labelledby="keep-mounted-modal-title"
      aria-describedby="keep-mounted-modal-description"
    >
      <Box sx={style}>
        <Card>
          <Box
            p={2}
            display="flex"
            alignItems="center"
            justifyContent="space-between"
          >
            <Typography variant="h5" gutterBottom>
              {`${feedback?.subject}`}
            </Typography>
          </Box>
          <Divider />
          <CardContent sx={{ p: 2 }}>
            <Typography variant="subtitle2">
              <Grid container spacing={0}>
                <Grid item xs={12} sm={4} md={3} textAlign={{ sm: 'right' }}>
                  <Box pr={3} pb={2}>
                    職番:
                  </Box>
                </Grid>
                <Grid item xs={12} sm={8} md={9}>
                  <Text color="black">
                    <b>{feedback?.userId}</b>
                  </Text>
                </Grid>
                <Grid item xs={12} sm={4} md={3} textAlign={{ sm: 'right' }}>
                  <Box pr={3} pb={2}>
                    種類:
                  </Box>
                </Grid>
                <Grid item xs={12} sm={8} md={9}>
                  <Text color="black">
                    <b>{changeJa(feedback?.tracker)}</b>
                  </Text>
                </Grid>
                <Grid item xs={12} sm={4} md={3} textAlign={{ sm: 'right' }}>
                  <Box pr={3} pb={2}>
                    内容:
                  </Box>
                </Grid>
                <Grid item xs={12} sm={8} md={9}>
                  <Text color="black">
                    <b>{feedback?.description}</b>
                  </Text>
                </Grid>
                <Grid item xs={12} sm={4} md={3} textAlign={{ sm: 'right' }}>
                  <Box pr={3} pb={2}>
                    ファイル:
                  </Box>
                </Grid>
                <Grid item xs={12} sm={8} md={9}>
                  <Text color="black">
                    <b>{feedback?.fileName}</b>
                  </Text>
                </Grid>
              </Grid>
            </Typography>
          </CardContent>
        </Card>
      </Box>
    </Modal>
  );
};

export default FeedbackDetailModal;
