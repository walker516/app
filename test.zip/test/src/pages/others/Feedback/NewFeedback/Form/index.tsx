import { FC, Fragment } from 'react';
import {
  Box,
  Button,
  FormControl,
  FormControlLabel,
  FormLabel,
  Grid,
  TextField,
  Radio,
  RadioGroup,
  styled
} from '@mui/material';
import UploadTwoToneIcon from '@mui/icons-material/UploadTwoTone';

import Text from 'src/components/Text';
import { PostFeedback } from 'src/types/feedback';

type Props = {
  changeFormValues?: (formValues: PostFeedback) => void;
  formValues: PostFeedback;
  userIdErr?: string;
  subjectErr?: string;
  changeUploadFile?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  postFileData?;
};

const Input = styled('input')({
  display: 'none'
});

const Form: FC<Props> = ({
  changeFormValues,
  formValues,
  postFileData,
  changeUploadFile,
  subjectErr,
  userIdErr
}) => {
  const handleTextFieldChange = (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = event.target;
    changeFormValues({
      ...formValues,
      [name]: value
    });
  };
  return (
    <Fragment>
      <Grid container spacing={3}>
        <Grid item xs={12} sm={6}>
          <TextField
            id="userId"
            name="userId"
            label="職番"
            fullWidth
            variant="standard"
            defaultValue={formValues.userId}
            onChange={handleTextFieldChange}
            error={userIdErr !== ''}
            helperText={userIdErr}
          />
        </Grid>
        <Grid item xs={12}>
          <FormControl component="fieldset">
            <FormLabel component="legend">種類</FormLabel>
            <RadioGroup
              row
              aria-label="tracker"
              name="tracker"
              sx={{
                '& .MuiTextField-root': { m: 1, width: '25ch' }
              }}
              defaultValue={formValues.tracker}
              onChange={handleTextFieldChange}
            >
              <FormControlLabel value="1" control={<Radio />} label="不具合" />
              <FormControlLabel value="2" control={<Radio />} label="要望" />
              <FormControlLabel
                value="3"
                control={<Radio />}
                label="その他(サポート, API関連)"
              />
            </RadioGroup>
          </FormControl>
        </Grid>
        <Grid item xs={12}>
          <TextField
            id="subject"
            name="subject"
            label="題目 "
            fullWidth
            variant="standard"
            defaultValue={formValues.subject}
            onChange={handleTextFieldChange}
            error={subjectErr !== ''}
            helperText={subjectErr}
          />
        </Grid>
        <Grid item xs={12}>
          <TextField
            id="description"
            name="description"
            label="説明"
            fullWidth
            variant="filled"
            multiline
            rows={5}
            defaultValue={formValues.description}
            onChange={handleTextFieldChange}
          />
        </Grid>
        <Grid item xs={12}>
          <Box>
            <Input
              accept=".xlsx,.xls,image/*,.doc, .docx,.ppt, .pptx,.txt,.pdf"
              id="upload"
              multiple
              type="file"
              onChange={changeUploadFile}
            />
            <label htmlFor="upload">
              <Button
                startIcon={<UploadTwoToneIcon />}
                variant="contained"
                component="span"
              >
                添付ファイル
              </Button>
            </label>
          </Box>
          <Text color="info">{postFileData?.name}</Text>
        </Grid>
      </Grid>
    </Fragment>
  );
};

export default Form;
