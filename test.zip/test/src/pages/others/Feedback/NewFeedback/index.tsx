import { FC, Fragment, useState } from 'react';
import {
  Box,
  Button,
  Container,
  IconButton,
  Paper,
  Stepper,
  Step,
  StepLabel,
  Tooltip,
  Typography
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { useCookies } from 'react-cookie';

import { useApiPostIssues } from 'src/hooks/redmine/useApiPostIssues';
import { useApiPostAttachments } from 'src/hooks/redmine/useApiPostAttachments';
import { PostFeedback } from 'src/types/feedback';
import Form from './Form';
import Review from './Review';
import { TEST_USER_ID } from 'src/utils/url';

type Props = {
  onClose: () => void;
};

const NewFeedback: FC<Props> = ({ onClose }) => {
  const [cookies] = useCookies();
  const [userIdErr, setUserIdErr] = useState('');
  const [subjectErr, setSubjectErr] = useState('');
  const [postFileData, setPostFileData] = useState<File | null>(null);
  const [formValues, setFormValues] = useState<PostFeedback>({
    userId: cookies['ENV'] === undefined ? TEST_USER_ID : cookies['USER_ID'],
    tracker: '1',
    subject: '',
    description: ''
  }); // TODO: ユーザ情報にユーザ名追加を検討する - by Oka
  const { token, uploadFile } = useApiPostAttachments();
  const { postFeedback } = useApiPostIssues();
  const [activeStep, setActiveStep] = useState(0);

  const changeUploadFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setPostFileData(e.target.files[0]);
      changeFormValues({ ...formValues, postFileData: e.target.files[0] });
    } // File
  };

  const changeFormValues = (props: PostFeedback) => {
    setFormValues(props);
  };

  const validateForm = () => {
    const regexp = /^J0\d{6}$/;
    let error = false;
    if (!regexp.test(formValues.userId)) {
      error = true;
      setUserIdErr('有効な職番を入力してください');
    }
    if (formValues.subject === '') {
      error = true;
      setSubjectErr('題目を入力してください');
    }
    return error;
  };

  const handleNext = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    setUserIdErr('');
    setSubjectErr('');
    const error = validateForm();
    if (error) return;
    setActiveStep(activeStep + 1);
    if (activeStep === 0) {
      if (formValues.postFileData) {
        uploadFile(formValues.postFileData); // TODO: Reveiwの後に添付ファイルをアップロードする仕様を検討する - by Oka
      }
    }
    if (activeStep === 1) {
      postFeedback(formValues, token);
    }
  };

  const handleBack = () => {
    setActiveStep(activeStep - 1);
  };

  const steps = ['Form', 'Review'];

  const getStepContent = (step: number) => {
    switch (step) {
      case 0:
        return (
          <Form
            changeFormValues={changeFormValues}
            formValues={formValues}
            userIdErr={userIdErr}
            subjectErr={subjectErr}
            changeUploadFile={changeUploadFile}
            postFileData={postFileData}
          />
        );
      case 1:
        return (
          <Review
            userId={formValues.userId}
            tracker={formValues.tracker}
            subject={formValues.subject}
            description={formValues.description}
            postFileData={postFileData}
          />
        );
      default:
        throw new Error('Unknown step');
    }
  };

  return (
    <Container component="main" maxWidth="sm" sx={{ mb: 4 }}>
      <Paper
        variant="outlined"
        sx={{ my: { xs: 3, md: 6 }, p: { xs: 2, md: 3 } }}
      >
        <Tooltip placement="top-end" title="Close">
          <IconButton color="primary" onClick={onClose}>
            <CloseIcon />
          </IconButton>
        </Tooltip>
        <Typography component="h1" variant="h4" align="center">
          新規作成
        </Typography>
        <Stepper activeStep={activeStep} sx={{ pt: 3, pb: 5 }}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>
        {activeStep === steps.length ? (
          <Fragment>
            <Typography variant="h5" gutterBottom>
              フィードバックありがとうございます。
            </Typography>
            <Typography variant="subtitle1">
              新規リストより確認してください。
            </Typography>
          </Fragment>
        ) : (
          <Fragment>
            {getStepContent(activeStep)}
            <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
              {activeStep !== 0 && (
                <Button onClick={handleBack} sx={{ mt: 3, ml: 1 }}>
                  Back
                </Button>
              )}
              <Button
                variant="contained"
                onClick={handleNext}
                sx={{ mt: 3, ml: 1 }}
              >
                {activeStep === steps.length - 1 ? 'Submit' : 'Next'}
              </Button>
            </Box>
          </Fragment>
        )}
      </Paper>
    </Container>
  );
};

export default NewFeedback;

// TODO: React Hook Form利用を検討する - by Oka
