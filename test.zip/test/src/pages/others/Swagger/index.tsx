import React from 'react';
import { Box, Container, Paper } from '@mui/material';
import SwaggerUIWrapper from './SwaggerUIWrapper';

const ApiDocumnet: React.FC = () => {
  return (
    <Container maxWidth="lg">
      <Paper>
        <SwaggerUIWrapper />
      </Paper>
    </Container>
  );
};

export default ApiDocumnet;
