import React from 'react';
import SwaggerUI, { SwaggerUIProps } from 'swagger-ui-react';
import 'swagger-ui-react/swagger-ui.css';
import { Box } from '@mui/material';

import { TEST_VBDB2_API_DOCS } from 'src/utils/url';

const SwaggerUIWrapper: React.FC<SwaggerUIProps> = (props) => {
  return (
    <Box>
      <SwaggerUI
        url={TEST_VBDB2_API_DOCS}
        docExpansion="list"
        deepLinking={true}
        defaultModelsExpandDepth={0}
        {...props}
      />
    </Box>
  );
};

export default SwaggerUIWrapper;
