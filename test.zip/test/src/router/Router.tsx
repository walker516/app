import { Navigate } from 'react-router-dom';
import { RouteObject, useRoutes } from 'react-router';

import PureLayout from 'src/layouts/PureLayout';
import BaseLayout from 'src/layouts/BaseLayout';
import Overview from 'src/pages/overview';
import DashboardGrid from 'src/pages/dashboards/DashboardGrid';
import Feedback from 'src/pages/others/Feedback';
import ApiDocument from 'src/pages/others/Swagger';
import Maintenance from 'src/pages/management/Maintenance';
import Error from 'src/pages/management/ Error';
import { Group } from 'src/types/group';

const routes: RouteObject[] = [
  {
    path: '',
    element: <PureLayout />,
    children: [
      {
        path: `/`,
        element: <Overview />
      },
      {
        path: `overview`,
        element: <Navigate to="/" replace />
      }
    ]
  },
  {
    path: 'dashboards',
    element: <BaseLayout />,
    children: [
      {
        path: '',
        element: <Navigate to="frame" replace />
      },
      {
        path: 'frame',
        element: <DashboardGrid group={Group.Frame} />
      },
      {
        path: 'engine',
        element: <DashboardGrid group={Group.Engine} />
      },
      {
        path: 'research',
        element: <DashboardGrid group={Group.Research} />
      },
      {
        path: 'other',
        element: <DashboardGrid group={Group.Other} />
      }
    ]
  },
  {
    path: 'others',
    element: <BaseLayout />,
    children: [
      {
        path: '',
        element: <Navigate to="feedback" replace />
      },
      {
        path: 'feedback',
        element: <Feedback />
      },
      {
        path: 'swagger',
        element: <ApiDocument />
      }
    ]
  },
  //利用していない
  {
    path: 'management',
    element: <PureLayout />,
    children: [
      {
        path: '',
        element: <Navigate to="maintenance" replace />
      },
      {
        path: 'maintenance',
        element: <Maintenance />
      },
      {
        path: 'error',
        element: <Error />
      }
    ]
  },
  // TODO: リロード時(F5)の対応を検討する　- by Oka
  {
    path: '*',
    element: <Overview />
  }
];

export const Router = () => {
  const content = useRoutes(routes);
  return <>{content}</>;
};
// TODO: コード分割のため、<Outlet />を活用し、react.lazy()の利用を検討する - by Oka
