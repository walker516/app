import { FC } from 'react';
import AdapterDateFns from '@mui/lab/AdapterDateFns';
import LocalizationProvider from '@mui/lab/LocalizationProvider';
import { CssBaseline } from '@mui/material';
import { BrowserRouter } from 'react-router-dom';
import useCookies from 'react-cookie/cjs/useCookies';
import { HelmetProvider } from 'react-helmet-async';

import { SidebarProvider } from './contexts/SidebarProvider';
import { Router } from './router/Router';
import ThemeProvider from './theme/ThemeProvider';

// TODO: 環境変数の取得方法を検討する（現在は cookie 経由）- by Oka
const getBaseName = (env: string) => {
  switch (env) {
    case 'local':
      return 'vbdb2_ui';
    case 'test':
      return 'integra_vbdb2_ui';
    case 'production':
      return 'vbdb2_ui';
    default:
      return '';
  }
};

const App: FC = () => {
  const [cookies] = useCookies();

  return (
    <ThemeProvider>
      <HelmetProvider>
        <SidebarProvider>
          <LocalizationProvider dateAdapter={AdapterDateFns}>
            <BrowserRouter basename={getBaseName(cookies['ENV'])}>
              <CssBaseline />
              <Router />
            </BrowserRouter>
          </LocalizationProvider>
        </SidebarProvider>
      </HelmetProvider>
    </ThemeProvider>
  );
};

export default App;
