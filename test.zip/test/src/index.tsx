import ReactDOM from 'react-dom';
import { CookiesProvider } from 'react-cookie';
import 'nprogress/nprogress.css';

import App from 'src/App';

ReactDOM.render(
  <CookiesProvider>
    <App />
  </CookiesProvider>,
  document.getElementById('root')
);
